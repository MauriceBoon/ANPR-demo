# Constraints

Verzameling van harde randvoorwaarden waaraan het nieuwe/herontworpen proces moet voldoen, gebaseerd op de werkinstructies P-100, P-200, P-210 en P-300 (versie 03/2026).

## Wettelijke / vormvereisten (compliance)

- Een opzegging (P-100) is wettelijk vormgebonden: zij moet **schriftelijk met handtekening** gebeuren. Een enkele e-mailverklaring of mondelinge melding is onvoldoende. (P-100)
- Acceptabele vormen van opzegging: gescande/gefotografeerde ondertekende brief, brief, fax. Niet acceptabel: ongetekende e-mail, mondelinge telefonische melding. (P-100)
- Herroeping van het contract is alleen mogelijk binnen de wettelijke herroepingstermijn van **14 dagen** na sluiting. (P-100)
- Opzegging met terugwerkende kracht is in de particuliere zorgverzekering in beginsel **niet mogelijk** (wettelijke verzekeringsplicht) — uitzondering: bijzondere opzegging bij overgang naar het publieke stelsel werkt pas vanaf de datum van overgang, niet eerder. (P-100)
- Bij opzegging wegens wisseling van aanbieder is wettelijk **bewijs van vervolgverzekering** vereist; zonder bewijs is de opzegging formeel onvolledig. (P-100)
- Bijzondere opzegging wegens premieverhoging moet binnen **4 weken** na ontvangst van de premieaanpassing worden verklaard om op de aanpassingsdatum van kracht te worden. (P-100)
- Gewone opzegging kan pas van kracht worden op de eerstvolgende mogelijke contractafloop, met inachtneming van de contractuele opzegtermijn (doorgaans 3 maanden) en de minimale looptijd van het contract. (P-100)
- Een formele contractbeëindiging bij overlijden vereist de **overlijdensakte** (origineel of gewaarmerkte kopie); zonder akte kan geen formele beëindiging plaatsvinden — een telefonische melding alleen is niet voldoende. (P-200)
- Standaardregel bij overlijden: het contract eindigt **met terugwerkende kracht per de overlijdensdatum** van de verzekeringnemer (wettelijke regeling); te veel betaalde premies worden terugbetaald. (P-200)
- Uitbetaling van een premietegoed na overlijden vereist een rechtmatige begunstigde: hetzij de aanvrager met een verklaring van erfrecht, hetzij de gemeenschap van erfgenamen. (P-200)
- Bij contractovername na overlijden (P-210) is een **schriftelijke, ondertekende overnameverklaring** van de nieuwe verzekeringnemer vereist; de overname gebeurt niet automatisch. (P-210)
- Een erfgenaam moet zich bij bevoegdheidscontrole legitimeren met een verklaring van erfrecht of een gewaarmerkte kopie van het testament. (P-210)
- Bij minderjarige kinderen die na een overlijden op het contract blijven, moet de wettelijke vertegenwoordiger (overgebleven ouder of voogd) als nieuwe verzekeringnemer optreden; bij voogdij moet het benoemingsbesluit worden aangetoond. (P-210)
- Een verzoek tot contractsplitsing moet schriftelijk en ondertekend door de betrokken verzekerde worden ingediend. (P-210)
- Bij collectieve tarieven (P-300) hebben verzekerden een wettelijk recht op voortzetting als individuele zorgverzekering na einde van de regeling, **zonder nieuwe gezondheidsbeoordeling** en met aanrekening van eerdere verzekerde tijdvakken; dit moet actief gecommuniceerd worden met een termijn (doorgaans 2 maanden). (P-300)
- Opzegging van het mantelcontract door de werkgever moet de contractuele opzegtermijn (doorgaans 3 maanden voor afloop) respecteren. (P-300)

## Bevoegdheid / autorisatie (rollen)

- Alleen de volgende partijen zijn bevoegd een opzegging (P-100) in te dienen: de verzekeringnemer zelf (handtekening verplicht), een gevolmachtigde met een volmacht die de opzegging uitdrukkelijk omvat, de verzekerde persoon (meerderjarig) voor het eigen tarief binnen een gezinscontract, of ouders voor minderjarige kinderen. (P-100)
- Een tussenpersoon kan een opzegging namens de klant doorsturen, maar kan niet in eigen naam verklaren; de handtekening van de verzekeringnemer blijft vereist. (P-100)
- Een uitvaartonderneming is geen formeel gevolmachtigde; voor verdere handelingen dan de melding/beëindiging zelf (bijv. uitbetaling van een premietegoed) is rechtstreekse communicatie met de nabestaanden of een bewijs van erfopvolging vereist. (P-200)
- Een uitvaartonderneming kan het overlijden melden, maar mag niet over een contractovername (P-210) beslissen. (P-210)
- Bij overname van een contract na overlijden moet de nieuwe verzekeringnemer als verzekerde op het bestaande contract staan of erfgerechtigd zijn. (P-210)
- Een gevolmachtigde bij een P-210-casus moet een voorzorgsvolmacht hebben die over het overlijden heen reikt, of een speciale algemene volmacht. (P-210)
- Bij een werkgeversverzekering (P-300) kan alleen een bevoegd vertegenwoordiger van de werkgever (HR/directie) met handtekening het mantelcontract opzeggen; een tussenpersoon heeft hiervoor een volmacht van de werkgever nodig. (P-300)
- Een individuele verzekerde onder een mantelcontract kan alleen het eigen tarief opzeggen (opt-out), mits de voorwaarden dit toestaan. (P-300)

## Proces-routering / afbakening (verplichte scheiding van processtromen)

- Overlijden van de verzekeringnemer mag nooit via P-100 worden afgehandeld; dit moet via P-200 (standaardgeval) of P-210 (complexe constellatie) lopen. (P-100, P-200)
- Beëindiging van een collectieve werkgeversverzekering mag nooit via P-100 worden afgehandeld; dit moet via P-300 lopen. (P-100, P-300)
- Opzegging van een reisziektekostenverzekering moet worden doorgestuurd naar het team Reisverzekeringen, niet via P-100 afgehandeld. (P-100)
- Speciale tarieven met eigen verwerking moeten naar het team Speciale Tarieven. (P-100)
- Dagvergoeding bij zelfstandigen met een bijzonder opzegrecht vereist specialistische beoordeling, niet standaard P-100-afhandeling. (P-100)
- Standaardopzegging van particuliere zorg zonder collectief verband moet via P-100 lopen, niet via P-300. (P-300)
- Overlijden van een collectief verzekerde persoon moet via P-200/P-210 lopen, niet via P-300. (P-300)
- Verzoeken om verklaringen over de regeling (bijv. bewijs werkgeversbijdrage) moeten naar F-440 of F-470, niet via P-300 worden afgehandeld. (P-300)
- Voorbereidende vragen bij leven over wat er bij overlijden gebeurt, mogen niet als P-210-dossier (overname/splitsing) worden geboekt, maar als adviesdossier; de overnameverklaring kan pas na het overlijden worden opgesteld. (P-210)
- In P-210 start elk overlijden in de praktijk met P-200; P-210 wordt alleen parallel of als vervolgproces aangemaakt wanneer de constellatie tot overname/splitsing leidt. (P-210)

## Dossier- en documentatieverplichtingen

- Elk inkomend verzoek moet in het kernsysteem aan het juiste contract en procestype (P-100 / P-200 / P-210 / P-300) worden toegewezen voordat verdere verwerking plaatsvindt. (alle processen)
- Contract-/dossierzoekwerk moet gebeuren op polisnummer, geboortedatum met achternaam, of klantnummer (P-100/P-200/P-210), resp. mantelcontractnummer en/of personeelsnummer (P-300).
- Elk dossier moet voorgeschreven kernvelden documenteren voor het als "afgehandeld" mag worden gesloten (per proces verschillend, zie werkinstructies): o.a. opzegtype/aanleiding, (effectieve) datum, ontvangstdatum, reden bij bijzonder geval, vervolgprocessen. (alle processen)
- Een overlijdensakte blijft een permanent onderdeel van het dossier zodra ingediend. (P-200)
- Bij een reeds bestaand P-200-dossier voor een verzekeringnemer mag de overlijdensakte niet opnieuw worden opgevraagd; er moet naar het bestaande dossier worden verwezen. (P-200)

## Termijnen (hervatting / wachttijd)

- Bij ontbrekende overlijdensakte: hervatting instellen over **14 dagen**, nabestaanden om nazending verzoeken; beëindiging mag pas worden geboekt zodra de akte aanwezig is. (P-200)
- Bij ontbrekende overnameverklaring (P-210): hervatting instellen over **30 dagen**. (P-210)
- Bij uitoefening van het voortzettingsrecht (P-300): verzekerden krijgen doorgaans **2 maanden** de tijd om het recht uit te oefenen. (P-300)
- Bijzondere opzegging wegens premieverhoging moet binnen **4 weken** na ontvangstmelding worden verklaard om op de aanpassingsdatum te werken. (P-100)

## Overig

- Bij contracten binnen de minimale looptijd is een gewone opzegging niet mogelijk; alleen een bijzonder opzegrecht, herroeping (binnen 14 dagen), of opzegging per einde van de minimale looptijd is toegestaan. (P-100)
- Bij dubbele indiening van documenten (bijv. overlijdensakte door meerdere melders) mag niet opnieuw om documenten worden gevraagd als het dossier al bestaat — faalpunt dat moet worden vermeden. (P-200)
- Communicatie met nabestaanden moet respectvol en empathisch zijn; gestandaardiseerde formuleringen moeten worden vermeden zonder de feitelijke helderheid te verliezen. (P-200)
- Bij herhaaldelijk onvolledige overnameverklaringen moet concreet worden benoemd welk gegeven ontbreekt, geen generieke standaardcorrespondentie. (P-210)

## Beëindiging na overlijden — scope en wettelijk kader (POL-KS-017)

- Het beleid geldt voor alle particuliere schadeverzekeringen van Polderzeker, ongeacht distributiekanaal (direct, adviseur, volmacht), en voor alle medewerkers, systemen en externe dienstverleners die een rol hebben in de afhandeling. (POL-KS-017 §1.1)
- Buiten de reikwijdte vallen: levensverzekeringen, uitvaartverzekeringen, arbeidsongeschiktheidsverzekeringen (vallen onder POL-LV-004), en zakelijke polissen waarbij de verzekeringnemer een rechtspersoon is. Bij overlijden van de eigenaar van een eenmanszaak/vof moet worden doorverwezen naar Zakelijk. (POL-KS-017 §1.1)
- Op grond van art. 7:950 BW kunnen erfgenamen én verzekeraar de schadeverzekering opzeggen binnen **9 maanden** na kennisname van het overlijden, met een opzegtermijn van **1 maand**; zonder opzegging loopt de verzekering door en gaat over op de erfgenamen. (POL-KS-017 §2)
- Zolang een kenteken op naam van de overledene staat en niet is geschorst, moet er een WA-verzekering (WAM) blijven bestaan; een autopolis mag daarom nooit worden beëindigd vóórdat het RDW-kentekenregister is gecontroleerd op overschrijving, schorsing of sloop. (POL-KS-017 §2, §4.1, C-BUS-03)
- Een besluit dat rechtsgevolgen heeft voor erfgenamen (zoals opzegging door Polderzeker) mag niet uitsluitend geautomatiseerd worden genomen; recht op menselijke tussenkomst is verplicht (AVG art. 22). (POL-KS-017 §2)
- Gegevens van overledenen vallen niet onder de AVG; gegevens van erfgenamen en melders wel. (POL-KS-017 §2)
- DORA (Verordening (EU) 2022/2554) is van toepassing sinds 17 januari 2025 en vereist een ICT-risicobeheerkader, toegangs- en wijzigingsbeheer, logging, continuïteitsplannen, incidentmelding aan DNB, testen van digitale weerbaarheid en beheer van ICT-dienstverleners (incl. informatieregister). (POL-KS-017 §2, §8)
- Al zijn de AI-toepassingen in dit proces juridisch geen hoog-risicosystemen onder de AI-verordening, past Polderzeker er bewust de waarborgen voor menselijk toezicht uit art. 14 AI-verordening op toe. (POL-KS-017 §2, kader)
- AI-geletterdheid (art. 4 AI-verordening, sinds 2 februari 2025) en de transparantieplicht voor chatbots (art. 50, sinds 2 augustus 2026) zijn van toepassing. (POL-KS-017 §2)

## Beëindiging na overlijden — kernregels (uitgangspunten)

- Geen beëindiging op initiatief van Polderzeker zonder menselijke beslissing: alleen gebruik van het opzegrecht uit art. 7:950 BW na een gemotiveerd besluit van een senior behandelaar; een systeem mag dit voorstellen, niet uitvoeren. (POL-KS-017 §3, C-AI-06)
- Opzegging door erfgenamen moet altijd worden gehonoreerd als die binnen de wettelijke termijn van 9 maanden valt en de melder bevoegd is; buiten de termijn beslist een medewerker over coulance (het systeem mag niet automatisch weigeren). (POL-KS-017 §3)
- De automatische incasso moet binnen **1 werkdag** na een geverifieerde melding worden opgeschort; de dekking moet ondertussen doorlopen totdat de polis is beëindigd of overgezet (geen gelijktijdige stopzetting van dekking). (POL-KS-017 §3, C-BUS-01)
- Iedere AI-uitkomst onder de vastgestelde betrouwbaarheidsdrempel, en iedere afwijking tussen bronnen, moet naar handmatige beoordeling. (POL-KS-017 §3)
- Van iedere beslissing moet herleidbaar worden vastgelegd wie of wat haar nam, op basis van welke gegevens en welke modelversie. (POL-KS-017 §3, C-DORA-03)
- Er moet altijd een volledig handmatige noodroute beschikbaar zijn wanneer een systeem of dienstverlener uitvalt. (POL-KS-017 §3, bijlage B)

## Beëindiging na overlijden — verplichte handmatige handelingen (triggers)

- Elk voorstel om een polis op initiatief van Polderzeker te beëindigen vereist inhoudelijke beoordeling en een gemotiveerd besluit van een senior behandelaar, vastgelegd in het dossier. (POL-KS-017 §5.1)
- AI-uitkomsten onder de drempel (matching < 0,95; documentherkenning < 0,90; classificatie < 0,85) vereisen volledige handmatige beoordeling op basis van het brondocument. (POL-KS-017 §5.1, C-AI-01/02/03)
- Signalen van mogelijke documentvervalsing/manipulatie vereisen beoordeling door een fraudespecialist (Afdeling Speciale Zaken); geen verdere verwerking tot de uitkomst bekend is. (POL-KS-017 §5.1)
- Een melder die om contact met een mens vraagt of bezwaar maakt tegen een geautomatiseerde stap, moet binnen **1 werkdag** persoonlijk contact krijgen. (POL-KS-017 §5.1)
- Signalen van kwetsbaarheid (verwarring, financiële nood, minderjarige melder) vereisen persoonlijk contact, eventueel een vaste contactpersoon. (POL-KS-017 §5.1)
- Elke door AI opgestelde brief of e-mail moet door een medewerker worden gelezen, waar nodig aangepast en zelf verzonden; AI mag niet zelfstandig verzenden. (POL-KS-017 §5.1, C-AI-04)
- Wijziging van een AI-model, prompt, drempelwaarde of beslisregel vereist voorafgaande goedkeuring door de AI-governancecommissie, vóór productie. (POL-KS-017 §5.1, C-AI-08)
- Bevoegdheid van de melder moet altijd worden vastgesteld vóór opzegging of restitutie > €250. (POL-KS-017 stap 4, C-BUS-02)
- Beoordeling per polis is altijd verplicht handmatig bij: auto (C-BUS-03), open schade (C-BUS-04), leegstaande woning (C-BUS-05). (POL-KS-017 stap 5)
- Restitutie naar een nieuw/onbekend IBAN vereist een vier-ogencontrole door een tweede medewerker (gescheiden rollen) die IBAN-naamcontrole en bevoegdheid verifieert. (POL-KS-017 §5.2, C-DORA-04)
- Restitutie hoger dan **€2.500** per dossier vereist vier-ogencontrole en goedkeuring in het betaalsysteem door een senior behandelaar. (POL-KS-017 §5.2, C-DORA-04)
- Batchverwerking die meer dan **25 dossiers** tegelijk raakt (bv. massale incassostop) vereist een steekproef van 10 dossiers en vrijgave door de teamleider voordat de batch definitief wordt. (POL-KS-017 §5.2, C-DORA-09)
- Een storing van workflow-, AI- of polissysteem langer dan **4 uur** verplicht tot overschakelen op het handmatige noodproces. (POL-KS-017 §5.2, bijlage B)
- Afwijkend systeemgedrag (stijging van automatisch afgehandelde/afgewezen dossiers > 2× het weekgemiddelde) verplicht tot pauzeren van de automatisering en onderzoek. (POL-KS-017 §5.2)
- Elke wijziging in software, configuratie of koppelingen van het proces moet via het change-proces: wijzigingsverzoek, test in acceptatie, goedkeuring door iemand anders dan de ontwikkelaar (Change Advisory Board). (POL-KS-017 §5.2, C-DORA-05)
- Een nieuwe of gewijzigde ICT-dienstverlener vereist risicobeoordeling, contracttoets op art. 30 DORA en opname in het informatieregister. (POL-KS-017 §5.2, C-DORA-07)
- Autopolis mag pas worden beëindigd na RDW-kentekencontrole; bij kenteken nog op naam van de overledene wordt voortzetting aangeboden; ANPR-registratie of recent schadegeval na overlijdensdatum vereist contact vóór beëindiging. (POL-KS-017 §4.1, C-BUS-03)
- Bij woonhuis/inboedel moet de behandelaar erfgenamen actief wijzen op leegstandsbepalingen en dit vastleggen in het dossier. (POL-KS-017 §4.1, C-BUS-05)
- Open of nieuwe schademelding op een polis vereist afstemming met de schadebehandelaar vóór beëindiging. (POL-KS-017 §5.3, C-BUS-04)
- Opzegverzoek van erfgenamen buiten de termijn van 9 maanden vereist een gemotiveerde coulancebeslissing door een senior behandelaar. (POL-KS-017 §5.3)
- Bij meerdere erfgenamen met tegenstrijdige verzoeken: contact met notaris/executeur, geen wijziging tot er duidelijkheid is. (POL-KS-017 §5.3)
- Kan de melder de bevoegdheid niet aantonen, dan mag alleen de incasso worden opgeschort, geen opzegging worden verwerkt, totdat de benodigde documenten zijn geleverd. (POL-KS-017 §5.3)

## Beëindiging na overlijden — AI-governance en menselijk toezicht

- Elke AI-toepassing moet in het centrale AI-register staan met eigenaar, doel, gebruikte data, leverancier en niveau van menselijk toezicht. (POL-KS-017 §6.1)
- Niveau van toezicht per AI-toepassing is vastgelegd en mag niet worden verlaagd zonder governance-besluit: AI-1 human-on-the-loop; AI-2/AI-3 human-in-the-loop onder drempel; AI-4 human-in-the-loop 100%; AI-5 human-on-the-loop met escalatie. Voor het proces als geheel geldt human-in-command (proceseigenaar kan elke AI-toepassing op elk moment uitzetten). (POL-KS-017 §6.1)
- Een beoordelaar moet altijd het originele brondocument naast de AI-uitkomst zien (niet alleen samenvatting/score), en het scherm moet tonen waarom de AI tot de uitkomst kwam. (POL-KS-017 §6.2)
- Wijkt een beoordelaar af van de AI, dan is een korte motivering verplicht vastgelegd; volgt de beoordelaar de AI, dan is dat niet verplicht gemotiveerd maar wel gelogd. (POL-KS-017 §6.2)
- Beoordelaars moeten een AI-geletterdheidstraining hebben gevolgd (art. 4 AI-verordening) voordat zij dossiers mogen beoordelen. (POL-KS-017 §6.2)
- Er geldt een minimumtijd van **6 minuten** per dossier voor een handmatige verificatie; er mag geen productienorm gelden die zorgvuldige beoordeling onmogelijk maakt. (POL-KS-017 §6.2)
- De chatbot moet bij de eerste interactie duidelijk maken dat het een geautomatiseerd systeem is en in elk antwoord de mogelijkheid bieden om met een medewerker te spreken (art. 50 AI-verordening). (POL-KS-017 §6.3, C-AI-05)
- De chatbot (AI-5) mag geen toezeggingen doen over opzegging of restitutie. (POL-KS-017 §6.1)
- De bevestigingsbrief moet in gewone taal vermelden dat software is gebruikt, dat een medewerker het dossier heeft gecontroleerd, en dat de nabestaande om uitleg of herbeoordeling kan vragen. (POL-KS-017 §6.3)
- Een stijging van de foutmarge van een AI-model met meer dan **20%** ten opzichte van het vorig kwartaal verplicht tot herbeoordeling van het model. (POL-KS-017 §6.4)

## Beëindiging na overlijden — controls, DORA en logging

- Minimaal 5% van de automatisch afgehandelde dossiers (en minimaal 20 per maand) moet maandelijks via steekproef worden gecontroleerd. (POL-KS-017 C-AI-07)
- Toegang tot het proces moet op basis van rollen en minimale rechten zijn ingericht, met kwartaalreview van autorisaties. (POL-KS-017 C-DORA-01)
- Functiescheiding is verplicht: wie een restitutie invoert, kan deze niet zelf goedkeuren. (POL-KS-017 C-DORA-02)
- Een volledige audit trail per beslissing (gebruiker/systeem, tijdstip, gebruikte gegevens, modelversie) is verplicht en moet doorlopend worden vastgelegd. (POL-KS-017 C-DORA-03)
- Logbestanden van beslissingen (incl. modelversie en destijds geldende drempelwaarde) moeten **7 jaar** na afsluiting van het dossier worden bewaard. (POL-KS-017 §8.4)
- Het handmatige noodproces moet jaarlijks worden getest in een scenario-oefening. (POL-KS-017 C-DORA-06)
- Afwijkend volume of een storing moet binnen **1 uur** worden beoordeeld op een mogelijk ICT-incident. (POL-KS-017 C-DORA-08)
- Een ernstig ICT-incident vereist een eerste melding aan DNB binnen **4 uur** na classificatie en uiterlijk **24 uur** na ontdekking, een tussentijds rapport binnen **72 uur** en een eindrapport binnen **1 maand**. (POL-KS-017 §8.2)
- Herstel van door een fout getroffen dossiers gebeurt altijd handmatig; getroffen klanten krijgen een persoonlijke brief en, bij een dekkingsgat, herstel van dekking met terugwerkende kracht. (POL-KS-017 §8.2)
- Contracten met externe dienstverleners (bv. voor AI-3, AI-5) moeten minimaal vastleggen: locatie van gegevensverwerking binnen de EER, auditrechten voor Polderzeker en DNB, meldplicht bij incidenten binnen 24 uur, vooraankondiging van modelwijzigingen, en een exitregeling met overstaptermijn van maximaal 3 maanden. Een leverancier mag gegevens van nabestaanden niet gebruiken om eigen modellen te trainen. (POL-KS-017 §8.3)
- Tijdens het handmatige noodproces mogen geen polissen worden beëindigd en geen restituties worden uitbetaald, tenzij de proceseigenaar daar per dossier toestemming voor geeft. (POL-KS-017 bijlage B)
- Het noodregister moet na herstel door een tweede medewerker worden gecontroleerd en daarna worden vernietigd. (POL-KS-017 bijlage B)
- Afwijkingen van de controls in hoofdstuk 7 vereisen schriftelijke instemming van Compliance (of, voor DORA-controls, van de ICT-risicomanager); afwijkingen die de verplichte menselijke beoordeling overslaan zijn nooit toegestaan. (POL-KS-017 §11)
