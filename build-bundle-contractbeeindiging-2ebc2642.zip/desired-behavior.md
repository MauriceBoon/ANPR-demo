
# Desired Behavior

Deze processen zijn werkinstructies die het **gewenste / voorgeschreven verloop** beschrijven voor de
afhandeling van contractbeëindigende verzoeken binnen Contractservice (versie 03/2026). Per proces staat
hieronder: trigger, actoren, te volgen stappen, beslislogica, verwachte uitkomst en afsluitcriteria. Faalpunten,
foutpercentages en overige huidige-staat-feiten zijn bewust weggelaten (zie current-state.md); hier staat
uitsluitend hoe de medewerker het verzoek **zou moeten** afhandelen.

## Overkoepelend doel van de processet (P-100 / P-200 / P-210 / P-300)
- Elk binnenkomend beëindigingsverzoek moet eenduidig aan het juiste procestype worden toegewezen
  (P-100 algemene opzegging, P-200 standaard overlijden, P-210 complexe overlijdensconstellatie, P-300
  werkgeversverzekering), zodat de juiste bevoegdheids-, bewijs- en afrekenlogica wordt toegepast.
- Elk dossier moet uiteindelijk de status "afgehandeld" krijgen, met volledige documentatie van: type
  verzoek/reden, (in werking tredende) datum, betrokken partijen, en gestarte vervolgprocessen.
- Correcte doorverwijzing tussen processen (P-100↔P-200/P-210↔P-300, en naar vervolgprocessen zoals
  F-410, F-420, F-430, F-440, F-450/F-460, F-470) is een expliciet onderdeel van "succesvol afgehandeld".

---

## P-100 Contractbeëindiging (opzegging, bijzondere opzegging, herroeping, bezwaar)

**Trigger:** inkomend verzoek (telefoon, e-mail, post, fax, tussenpersoon-kanaal) tot beëindiging van een
contract dat niet overlijden (P-200/P-210) of werkgeversverzekering (P-300) betreft.

**Gewenst procesverloop:**
1. Document toewijzen aan het contract in het kernsysteem, procestype P-100 selecteren. Bij telefonisch
   contact: verzoek vastleggen in het contactlog én de klant direct wijzen op de schriftelijke
   handtekeningvereiste.
2. Opzegtype vaststellen: gewone opzegging, bijzondere opzegging (met reden), opzegging van
   afzonderlijke tarieven, of herroeping (binnen 14 dagen).
3. Contract openen (op polisnummer, geboortedatum+achternaam, of klantnummer); status, ingangsdatum,
   minimale looptijd, eerstvolgende opzegdatum en lopende bijzondere opzegtermijnen controleren.
4. Bevoegdheid van de opzegger vaststellen (verzekeringnemer, gevolmachtigde, meerderjarige
   verzekerde voor eigen tarief, ouder voor minderjarig kind); bij tussenpersoon: doorsturen is toegestaan,
   maar de formele opzegging blijft de handtekening van de verzekeringnemer vereisen.
5. Werking en ingangsdatum van de opzegging bepalen volgens het opzegtype (contractafloop,
   premieaanpassing +4 weken, overgang publiek stelsel, herroeping met terugwerkende kracht).
6. Waar relevant: bewijs van vervolgverzekering controleren bij wisseling van aanbieder; zonder bewijs
   het dossier in de wachtrij zetten en het bewijs opvragen.
7. Doorsturen naar specialistische teams waar nodig (Reisverzekeringen, Speciale Tarieven, dagvergoeding
   zelfstandigen).
8. Beëindiging verwerken: einddatum (of einddatum van een deelopzegging) vastleggen; systeem
   genereert een opzegbevestiging die vóór verzending op datum-logica wordt gecontroleerd.
9. Vervolgprocessen starten waar van toepassing (F-410 voorgaande/vervolgverzekering, F-420
   overdrachtswaarde, premieafrekening/teruggave).
10. Dossier documenteren (opzegtype, ingangsdatum, ontvangstdatum, reden, vervolgprocessen) en sluiten
    met status "afgehandeld".

**Verwachte uitkomst / succescriteria:**
- De klant ontvangt een opzegbevestiging met het juiste opzegtype, de juiste (ingangs)datum, vermelding
  van laatste premie-incasso/teruggave en, bij bijzondere opzegging, de wettelijke grondslag.
- Opzeggingen zonder geldige schriftelijke handtekening worden teruggelegd bij de verzekeringnemer
  (niet verwerkt op basis van een enkele e-mailverklaring of telefonische melding).
- Verzoeken om opzegging met terugwerkende kracht worden correct afgewezen, behalve bij overgang
  naar het publieke stelsel (ingangsdatum = overgangsdatum) of herroeping (terugwerkend tot
  ingangsdatum).
- Deelopzegging van één tarief in een meertarievencontract laat het hoofdcontract ongemoeid.

---

## P-200 Overlijden gemeld (standaardgeval)

**Trigger:** melding van overlijden van de verzekeringnemer (door uitvaartonderneming, nabestaanden,
gevolmachtigde, of tussenpersoon), doorgaans met overlijdensakte als bijlage.

**Gewenst procesverloop:**
1. Dossier aanmaken, procestype P-200, overlijdensakte als permanente bijlage toevoegen. Bij
   telefonische melding: direct nazending van de (gewaarmerkte) overlijdensakte vragen; zonder akte kan
   de beëindiging niet formeel plaatsvinden.
2. Overlijdensakte controleren op volledigheid: naam/geboortedatum overeenkomstig contractgegevens,
   overlijdensdatum aanwezig, juiste vorm (origineel/gewaarmerkte kopie/kopie).
3. Vóór het opvragen van documenten controleren of er al een P-200-dossier/akte voor deze
   verzekeringnemer bestaat; zo ja, niet opnieuw opvragen maar verwijzen naar het bestaande dossier.
4. Indien akte ontbreekt: dossier aanmaken, hervatting instellen over 14 dagen, nabestaanden beleefd om
   nazending verzoeken; beëindiging pas boeken zodra de akte aanwezig is.
5. Contract openen en de constellatie vaststellen: verzekeringnemer alleen verzekerd (volledige
   beëindiging), verzekeringnemer + gezin (voortzetting mogelijk, overnameverklaring vereist →
   gekoppeld aan P-210), of alleen een verzekerde (niet de verzekeringnemer) overleden (alleen dat tarief
   beëindigen, contract blijft bestaan).
6. Beëindiging boeken: contract eindigt met terugwerkende kracht per overlijdensdatum; premietegoed
   automatisch berekenen; vooruitbetaalde premie terugbetalen.
7. Uitbetaling premietegoed regelen aan de juiste begunstigde (aanvrager met verklaring van erfrecht, of
   gemeenschap van erfgenamen); bij grotere bedragen doorsturen naar team Tegoeden.
8. Openstaande declaraties (nog niet vergoede nota's) doorsturen naar Zorgdeclaraties voor behandeling
   namens de gemeenschap van erfgenamen.
9. Brief aan nabestaanden met: bevestiging beëindiging + datum, informatie premietegoed en
   uitbetalingswijze, voortzettingsmogelijkheden (indien van toepassing), verantwoordelijk onderdeel bij
   openstaande declaraties. Toon: respectvol en empathisch, geen generieke standaardformuleringen; bij
   twijfel over geadresseerde navragen in plaats van aannemen.
10. Vervolgprocessen starten waar relevant (uitbetaling tegoed, P-210 bij voortzetting, F-430
    nabestaandenpensioenverklaring, F-440 belastingverklaring laatste jaar).
11. Dossier documenteren (melder, overlijdensdatum, constellatie, premietegoedbedrag, vervolgprocessen)
    en sluiten met status "afgehandeld".

**Verwachte uitkomst / succescriteria:**
- Geen dubbele opvraging van de overlijdensakte wanneer meerdere partijen (nabestaanden,
  uitvaartonderneming, tussenpersoon) onafhankelijk melden.
- Correcte, tijdige en begripvolle communicatie met nabestaanden, met heldere feitelijke informatie over
  premietegoed en vervolgstappen.
- Juiste doorverwijzing naar P-210 zodra er verdere verzekerden zijn die het contract moeten voortzetten.

---

## P-210 Overlijden (complexe constellatie: overname, splitsing, overlijden van een verzekerde)

**Trigger:** een gemeld overlijden waarbij de contractconstellatie geherstructureerd moet worden
(contractovername door achterblijvende partner, contractsplitsing voor kinderen, of overlijden van een
verzekerde terwijl de verzekeringnemer in leven blijft). In de praktijk start elk overlijden met P-200; P-210
wordt parallel of als vervolgproces aangemaakt zodra de constellatie dit vereist.

**Gewenst procesverloop:**
1. Dossier aanmaken, procestype P-210; alle relevante documenten (overnameverklaring,
   splitsingsverzoek, correspondentie) als bijlage toevoegen.
2. Constellatie vaststellen: wie is overleden (verzekeringnemer of verzekerde), welke verdere verzekerden
   staan op het contract (en in welke status: meerderjarig/minderjarig/zorgbehoevend), en welke
   vervolgactie wordt gewenst (overname / splitsing / beëindiging).
3. Bij vragen "bij leven" (vóór een overlijden): dit is geen P-210-dossier; geef advies over
   voortzettingsmogelijkheden, documenteer als adviesdossier en sluit het. De overnameverklaring kan pas
   ná het overlijden worden opgesteld.
4. Bevoegdheid controleren met verhoogde eisen: nieuwe verzekeringnemer moet verzekerde zijn of
   erfgerechtigd; erfgenaam moet verklaring van erfrecht of gewaarmerkt testament overleggen;
   gevolmachtigde moet een volmacht hebben die over het overlijden heen reikt; een uitvaartonderneming
   kan wel melden maar niet over de overname beslissen.
5. Overnameverklaring verwerken (meest voorkomend): formulier controleren op volledigheid en
   ondertekening, bevestiging van niet-deelname aan een groepsverzekering, nieuwe contractgegevens
   vastleggen, tariefstatus/premie-impact controleren.
   - Bij ontbrekend formulier: vermoedelijke nieuwe verzekeringnemer aanschrijven, hervatting over 30
     dagen.
   - Bij uitdrukkelijke afwijzing van de overname: contract volledig beëindigen (terug naar P-200-logica).
   - Bij gedeeltelijk ingevuld formulier: concreet de ontbrekende gegevens benoemen (geen generieke
     "gelieve volledig" formulering), ook bij herhaalde onvolledige indiening.
6. Contractsplitsing verwerken wanneer resterende verzekerden eigen contracten willen: schriftelijk
   verzoek opvragen, nieuw polisnummer toekennen, tariefgegevens ongewijzigd overnemen, premie
   vastleggen, nieuwe polis verzenden. Bij minderjarige kinderen: de wettelijke vertegenwoordiger
   (overgebleven ouder/voogd) tekent de overnameverklaring; bij voogdij het benoemingsbesluit
   aantonen.
7. Bij overlijden van een verzekerde (niet de verzekeringnemer): overlijdensakte controleren en
   toevoegen, tarief van die verzekerde beëindigen per overlijdensdatum, premieafrekening aanpassen
   vanaf de volgende maand, condoleancebrief met bevestiging tariefbeëindiging versturen. Bij meerdere
   gelijktijdige overlijdens: elke verzekerde afzonderlijk boeken en zeer gevoelig communiceren.
8. Vervolgprocessen starten (P-200 parallel bij beëindiging verzekeringnemer, F-430
   pensioenverklaring, F-440 belastingverklaring, uitbetaling premietegoed).
9. Dossier documenteren (constellatie, nieuwe verzekeringnemer indien van toepassing, parallelle
   dossiers, tariefwijzigingen) en sluiten met status "afgehandeld".

**Verwachte uitkomst / succescriteria:**
- Nabestaanden krijgen heldere, specifieke en niet-generieke communicatie over ontbrekende gegevens bij
  een overnameverklaring.
- De juiste persoon treedt op als nieuwe verzekeringnemer (bevoegdheid correct getoetst, inclusief bij
  minderjarige kinderen en voogdij).
- Contractsplitsing en -overname worden correct en zonder premieherwaardering van bestaande tarieven
  verwerkt.

---

## P-300 Beëindiging werkgeversverzekering (collectieve zorgverzekering)

**Trigger:** beëindigingsverzoek binnen een collectief werkgeverscontract: opzegging van het
mantelcontract door de werkgever, uitdiensttreding van een medewerker, einde van de looptijd, opt-out,
of correctie van een dubbele polis.

**Gewenst procesverloop:**
1. Document toewijzen aan het collectieve contract, procestype P-300 selecteren; aanleiding helder
   vaststellen (opzegging mantelcontract / uittreding één verzekerde / opt-out / einde looptijd), omdat dit
   de vervolgstappen bepaalt.
2. Contract openen (op mantelcontractnummer en/of personeelsnummer); formele structuur controleren:
   verzekeringnemer (werkgever), opgenomen verzekerden, tariefconstellatie. Bevoegdheid controleren
   (werkgever via HR/directie met handtekening bevoegd vertegenwoordiger; verzekerde voor eigen
   tarief; tussenpersoon met volmacht van de werkgever).
3. Bij opzegging van het hele mantelcontract: opzegtermijn controleren (doorgaans 3 maanden),
   uniforme einddatum voor alle verzekerden bepalen, elke verzekerde individueel informeren over
   mogelijkheden (overstap individuele dekking of beëindiging), eindafrekening met de werkgever
   opstellen.
4. Voortzettingsrecht als individueel contract actief communiceren: elke verzekerde informeren met een
   termijn (doorgaans 2 maanden) om het recht uit te oefenen, zonder nieuwe gezondheidsbeoordeling en
   met verrekening van eerdere verzekerde tijdvakken.
   - Bij actieve uitoefening: vervolgproces voor individuele contractaanleg starten (F-450/F-460).
   - Bij niet-uitoefening: dekking eindigt op de peildatum.
5. Bij beëindiging van één verzekerde (uittreding/opt-out): aanleiding verhelderen, einddatum bepalen
   (doorgaans einde van de maand), voortzettingsmogelijkheden communiceren, premieafrekening
   aanpassen (eventueel tegoed terugbetalen).
   - Bij overstap naar nieuwe werkgever met eigen regeling: dekking rechtstreeks laten eindigen, F-410
     (verklaring voorgaande verzekering) als vervolgproces opstellen.
   - Bij dubbele polis: overtollige polis beëindigen met terugwerkende kracht, premies terugbetalen.
   - Bij uitdrukkelijke opt-out: schriftelijke bevestiging door de werkgever, dossier documenteren als
     opt-out, geen vervolgcontract.
6. Premie- en eindafrekening uitvoeren volgens het juiste niveau (hele mantelcontract met de werkgever,
   of premieaanpassing binnen het lopende mantelcontract bij één persoon minder; teruggave bij
   terugwerkende beëindiging).
7. Dossier documenteren (aanleiding, einddatum, betrokken personen, uitoefening voortzetting
   ja/nee/geen reactie, vervolgprocessen) en sluiten met status "afgehandeld"; bij wachttijd op
   voortzettingsbeslissingen een passende hervatting instellen.

**Verwachte uitkomst / succescriteria:**
- Elke verzekerde bij beëindiging van het mantelcontract ontvangt tijdig een individuele informatiebrief
  over het voortzettingsrecht; dit recht wordt actief gecommuniceerd, niet alleen passief beschikbaar
  gesteld.
- Correcte afbakening tussen "hele mantelcontract" en "één verzekerde" zodat het mantelcontract niet
  onterecht wordt beëindigd bij een individuele uittreding, en vice versa.
- Dubbele polissen en opt-outs worden correct en met terugwerkende-kracht-teruggave resp. zonder
  vervolgcontract afgehandeld.

---

## Beleid beëindiging schadeverzekeringen na overlijden (POL-KS-017)
Dit beleid beschrijft een ander proces dan P-100/P-200/P-210/P-300 (het betreft particuliere
**schadeverzekeringen** — auto, woonhuis, inboedel, aansprakelijkheid — na overlijden van de
verzekeringnemer, niet zorgverzekeringen) en bevat een expliciet toekomstgericht streefbeeld, inclusief
succescriteria. Alleen de gedragsdoelen zijn hieronder opgenomen; de onderliggende wettelijke verplichtingen
(DORA, AVG, WAM, AI-verordening e.d.) en de concrete controls staan in constraints.md.

### Doel van automatisering in dit proces
Het proces wordt grotendeels geautomatiseerd en zet AI in voor het lezen van brieven, het herkennen van
documenten en het koppelen van polissen, om twee terugkerende klachtoorzaken te elimineren: premie die
maanden na overlijden nog wordt afgeschreven, en polissen die worden beëindigd terwijl er nog een
verzekerd belang is (rijdende auto, bewoonde woning). Uitgangspositie: een systeem mag voorbereiden, een
mens beslist wanneer het initiatief tot beëindiging bij de verzekeraar ligt, wanneer geld naar een nieuw
rekeningnummer gaat, of wanneer het systeem twijfelt.

### Gedragsprincipes voor het doelproces
1. Geen beëindiging op initiatief van de verzekeraar zonder gemotiveerde menselijke beslissing van een
   senior behandelaar; een systeem mag dit alleen voorstellen.
2. Een tijdige en bevoegde opzegging door erfgenamen wordt altijd gehonoreerd; buiten de termijn beslist
   een medewerker over coulance (het systeem weigert nooit automatisch).
3. De automatische incasso wordt binnen 1 werkdag na een geverifieerde melding opgeschort; de dekking
   blijft echter doorlopen totdat de polis daadwerkelijk is beëindigd of overgezet.
4. Elke AI-uitkomst onder de vastgestelde betrouwbaarheidsdrempel, en elke afwijking tussen bronnen, gaat
   naar handmatige beoordeling ("twijfel gaat naar een mens").
5. Elke beslissing is herleidbaar: vastgelegd wordt wie/wat de beslissing nam, op basis van welke gegevens
   en welke modelversie.
6. Er is altijd een volledig handmatige noodroute beschikbaar wanneer een systeem of dienstverlener
   uitvalt (zie "Handmatig noodproces" hieronder).

### Doelproces in acht stappen
1. **Melding ontvangen** (portaal, telefoon, post, e-mail, adviseur, uitvaartondernemer): dossier aanmaken,
   ontvangst bevestigen binnen 2 werkdagen. AI classificeert post/e-mail en bedient een chatbot in het
   portaal; telefonische meldingen en onzekere classificaties gaan altijd handmatig.
2. **Polissen koppelen**: alle lopende polissen van de overledene zoeken (ook via adviseurs/volmachten);
   AI matcht op naam/geboortedatum/adres, maar bij een laag matchscore of meerdere kandidaten volgt
   altijd handmatige koppeling.
3. **Overlijden verifiëren**: akte, BRP-uittreksel of notariële/uitvaartverklaring controleren; AI leest het
   document en controleert op echtheid, maar bij lage zekerheid, een echtheidssignaal of een afwijking met
   polisgegevens volgt altijd handmatige verificatie.
4. **Bevoegdheid melder vaststellen** (verklaring van erfrecht, executele, volmacht): altijd handmatig, geen
   AI, en altijd verplicht vóór opzegging of een substantiële restitutie.
5. **Beoordeling per polis**: overzetten op partner/erfgenaam, laten doorlopen tot einde termijn, of
   beëindigen; het systeem mag een voorstel doen op basis van beslisregels, maar bij een auto, open
   schade of een leegstaande woning is handmatige beoordeling altijd verplicht.
6. **Opzegging verwerken**: einddatum en premie automatisch berekenen; opzegging op initiatief van de
   verzekeraar gaat altijd naar een senior behandelaar voor een gemotiveerd besluit.
7. **Premie en restitutie**: incasso automatisch stoppen en berekenen; bij een nieuw IBAN of een hoger
   bedrag is een vier-ogencontrole verplicht.
8. **Communicatie en afsluiting**: AI stelt een conceptbrief op, maar een medewerker leest en verstuurt
   elke brief persoonlijk voordat het dossier wordt gesloten en gearchiveerd.

Wat het systeem wél zelfstandig mag: ontvangst bevestigen, een dossier aanmaken, de incasso opschorten na
een geverifieerde melding, einddata/premies berekenen, conceptbrieven opstellen, en een opzegging door een
bevoegde erfgenaam binnen de termijn verwerken voor een polis zonder kenteken, open schade of
meeverzekerden (met achteraf steekproefcontrole).

### Bijzonderheden per verzekeringstype (doelgedrag)
- **Auto**: nooit beëindigen voordat is gecontroleerd dat het kenteken is overgeschreven, geschorst of
  gesloopt; staat het kenteken nog op naam van de overledene, dan wordt voortzetting tot verkoop
  aangeboden en wordt bij een signaal van gebruik (ANPR, recente schade) eerst contact gezocht.
- **Woonhuis/inboedel**: erfgenamen actief informeren over leegstandsbeperkingen in de dekking; dit
  wordt vastgelegd in het dossier.
- **Aansprakelijkheid particulieren**: kan per overlijdensdatum worden beëindigd zonder meeverzekerden;
  met een meeverzekerde partner wordt de polis op diens naam voortgezet.
- **Gezinspolissen/pakketten**: eindigen niet automatisch bij meeverzekerden; er wordt contact gezocht
  met de partner of inwonende kinderen.

### Doelgedrag voor AI-inzet en menselijk toezicht
- Elke AI-toepassing heeft een vastgesteld niveau van toezicht: human-in-the-loop (elke uitkomst wordt
  vóór uitvoering door een mens bekeken) voor matching, documentverificatie en conceptbrieven;
  human-on-the-loop (zelfstandig handelen binnen grenzen, met monitoring en ingrijpmogelijkheid) voor
  postclassificatie en de chatbot. Voor het proces als geheel geldt human-in-command: de proceseigenaar
  kan elke AI-toepassing op elk moment uitschakelen, waarna het proces handmatig doorloopt.
- Een menselijke beoordelaar moet altijd het originele brondocument zien naast de AI-uitkomst (niet alleen
  een score/samenvatting), en het scherm moet tonen waarom de AI tot haar uitkomst kwam.
- Afwijken van de AI-uitkomst vereist een korte motivering; de AI volgen wordt niet gemotiveerd maar wel
  gelogd. Een opvallend laag afwijkingspercentage van een beoordelaar (langdurig <2%) wordt
  steekproefsgewijs besproken, om "blind klikken op akkoord" te signaleren.
- Beoordelaars zijn getraind in AI-geletterdheid en kennen de bekende zwaktes van de modellen (bijv.
  slechtere prestatie op buitenlandse overlijdensakten). Er geldt geen productienorm die zorgvuldige
  beoordeling onmogelijk maakt (richttijd: minimaal 6 minuten per dossier).
- Nabestaanden krijgen transparantie: de chatbot maakt bij de eerste interactie duidelijk dat het een
  geautomatiseerd systeem is en biedt in elk antwoord de mogelijkheid om met een medewerker te spreken;
  de bevestigingsbrief legt in gewone taal uit dat software is gebruikt, dat een medewerker heeft
  gecontroleerd, en dat uitleg of herbeoordeling gevraagd kan worden.
- De modelprestaties worden doorlopend gemonitord (aandeel dossiers onder de drempel,
  afwijkingspercentage van beoordelaars, fout-positieven/negatieven, verschillen tussen groepen zoals
  buitenlandse versus Nederlandse akten); een duidelijke stijging van de foutmarge leidt tot herbeoordeling
  van het model.

### Handmatig noodproces (doelgedrag bij uitval)
Bij uitval van workflow-, AI- of polissysteem, of een leverancier, langer dan enkele uren: de teamleider
activeert het noodproces, nieuwe meldingen worden veilig geregistreerd, polissen worden zo mogelijk
handmatig gezocht, en er worden tijdens het noodproces geen polissen beëindigd en geen restituties
uitbetaald zonder expliciete toestemming per dossier van de proceseigenaar. Na herstel worden alle
noodregisterdossiers ingevoerd en door een tweede medewerker gecontroleerd, gevolgd door een evaluatie.

### Succescriteria (streefwaarden)
| Indicator | Streefwaarde |
| --- | --- |
| Ontvangstbevestiging na melding | binnen 2 werkdagen in 98% van de gevallen |
| Incasso opgeschort na geverifieerde melding | binnen 1 werkdag in 99% van de gevallen |
| Afronding dossier (alle polissen beoordeeld en bevestigd) | binnen 15 werkdagen na complete documentatie, in 90% van de gevallen |
| Afschrijvingen na overlijden die later zijn teruggestort | minder dan 1% van de dossiers |
| Onterecht beëindigde polissen | nul; elk geval wordt als incident onderzocht |
| Klachten over de afhandeling | minder dan 0,5% van de dossiers |
| Aandeel volledig handmatig behandelde dossiers | geen norm; wordt gevolgd om AI-inzet te kunnen beoordelen |

Afwijken van het beleid mag uitsluitend in het belang van de nabestaanden (bijv. coulance of een snellere
route bij een schrijnende situatie); afwijkingen die de verplichte menselijke beoordeling overslaan zijn niet
toegestaan.

---

## Niet in de bronnen beschreven
De vier werkinstructies (P-100/P-200/P-210/P-300) beschrijven uitsluitend de voorgeschreven
procesuitvoering en bevoegdheids-/bewijslogica, zonder expliciete KPI's of een toekomstig streefbeeld
voorbij de huidige stappen; dit wordt voor die processen niet verondersteld. Voor het beleid
beëindiging schadeverzekeringen na overlijden (POL-KS-017) is wel een expliciet streefbeeld met
succescriteria beschreven, zie hierboven.
