You are scaffolding a runnable prototype for the contractbeëindigingsprocessen (P-100 / P-200 / P-210 / P-300) of the Contractservice department. The working directory already contains `specification.md`, `current-state.md`, `desired-behavior.md`, `constraints.md`, `process-flow.json`, and `build-plan.md`. Read all of them before writing any code. `build-plan.md` is authoritative for stack, file tree, agents, data shapes, and run commands; `process-flow.json` is authoritative for nodes, output keys, and preconditions.

## Stack
Build a **Streamlit single-file-centric Python app** managed with **`uv`**. One external dependency: the LLM provider (Anthropic by default). Everything else runs locally. Default model constant: `claude-opus-4-8`, configurable via an environment variable.

## Scope
Implement all four processes end-to-end as a human-in-the-loop caseworker workflow:
1. Intake + routing (`route_process_type`) that assigns P-100/P-200/P-210/P-300 or "ander team".
2. P-100, P-200, P-210, P-300 node chains as they appear in `process-flow.json`.
LLM-backed nodes are the `execution_type: "human"` judgement/correspondence steps; implement `execution_type: "deterministic"` nodes (boeken, afrekenen, versturen, sluiten) as local stub functions. Vervolgprocessen F-410…F-470 are registration stubs only.

Enforce these desired-behavior improvements as explicit gates in the UI:
- **P-100 handtekeningcheck** — ongetekende e-mail / telefonische melding is ongeldig; leg het dossier terug bij de klant. Wijs terugwerkende opzegging af behalve bij overgang publiek stelsel of herroeping binnen 14 dagen. Valideer de opzegbevestiging op datum-logica vóór "verzenden".
- **P-200 dubbeldetectie** — controleer vóór het opvragen op een bestaand P-200-dossier (match op verzekeringnemer/contract); bij een dubbele melding verwijs je naar het bestaande dossier en vraag je de akte niet opnieuw op. Boek niet zonder akte (hervatting 14 dagen). Verifieer de geadresseerde vóór verzending van de nabestaandenbrief; houd de toon respectvol en niet-generiek.
- **P-210 veldspecifieke opvraag** — benoem bij een onvolledige overnameverklaring concreet welk gegeven ontbreekt (geen generieke correspondentie), ook bij herhaalde onvolledige indiening; hervatting 30 dagen. Behandel een "vraag bij leven" als adviesdossier, niet als P-210.
- **P-300 actieve communicatie voortzettingsrecht** — communiceer het recht op voortzetting als individueel contract actief met een termijn (doorgaans 2 maanden). Bewaak de afbakening heel mantelcontract vs. individuele uittreding.

## File tree
Create exactly the structure in `build-plan.md` → "File tree": `app.py`, `pyproject.toml`, `.env.example`, `.gitignore`, `README.md`, `core/` (`llm.py`, `state.py`, `router.py`, `followups.py`), `agents/` (`intake_classifier.py`, `p100.py`, `p200.py`, `p210.py`, `p300.py`), `data/` (`seed.py`, `fixtures/.gitkeep`, `cases.sample.json`), and `prompts/` (`intake.md`, `p100_signature.md`, `p200_relatives_letter.md`, `p210_missing_fields.md`, `p300_continuation.md`).

## Data shapes
Use the `Case` / `Dossier` model and the node-output flags from `build-plan.md` → "Data shapes". Use the exact output keys from `process-flow.json` (e.g. `p100_signature_valid`, `p200_duplicate_found`, `p210_takeover_incomplete`, `p300_is_full_contract`). Persist cases as JSON under `data/`. Record an audit entry per step (`actor` mens/ai, step, decision, rationale, model_version).

## Tasks (in order)
1. Scaffold the project: `pyproject.toml` with deps (streamlit, the Anthropic SDK, python-dotenv), `.gitignore` (ignore `.env`, `.venv`, `__pycache__`, `data/cases*.json`), and `.env.example` with placeholder `ANTHROPIC_API_KEY=your-key-here`.
2. Build `core/`: `llm.py` (client wrapper that reads the key from the environment; never hardcode it), `state.py` (Case model + status enums + JSON persistence), `router.py` (LLM-assisted routing with the hard separation rules from `constraints.md` enforced in code), `followups.py` (F-code registration stubs).
3. Implement `agents/` one process at a time (intake → P-100 → P-200 → P-210 → P-300), each returning a structured result plus an audit line. Put prompt text in `prompts/*.md` and load it from the agents.
4. Implement deterministic node stubs (boeken/afrekenen/versturen/sluiten) locally.
5. Build `app.py`: intake form, routing view with rationale, per-process stepper with the human-approval gates above, document/draft previews, and status badges driving the case to "afgehandeld".
6. Write `data/seed.py` to generate synthetic example cases covering at least one happy path and one gate-triggering case per process; write results to `data/cases.sample.json`. Leave `data/fixtures/` empty for the user's own cases.
7. Write `README.md` with the exact `uv` run commands from `build-plan.md`, a scope summary, and caveats.

## Acceptance criteria
- The prototype runs locally with: `cp .env.example .env` → fill the key → `uv venv` → `uv sync` → `uv run python data/seed.py` → `uv run streamlit run app.py`.
- At least one synthetic example input per process can be driven to a terminal status in the UI: P-100 to a sent confirmation (and a separate case to "teruggelegd" on missing signature), P-200 to a closed dossier (and a separate case hitting dubbeldetectie / missing-akte hold), P-210 to a closed takeover (and a separate case producing veldspecifieke opvraag), P-300 to a closed dossier with an active voortzettingsrecht letter.
- Human-approval gates are visibly present and block progression until a human action is taken.
- No API key, token, or internal gateway URL appears anywhere in source, config, prompts, fixtures, or the README. Credentials are read from environment variables / a local `.env` only; reference the public Anthropic endpoint.

## Guardrails
- Do not implement anything beyond `build-plan.md`. If you hit a genuine ambiguity or a needed decision that is not covered (including the still-open stack/scope/data/notes questions), stop and surface a question instead of guessing.
- Do not implement the POL-KS-017 schadeverzekeringen-na-overlijden policy or its DORA/AI-governance controls — that policy is in the source documents but is out of scope for this flow and prototype.
- Keep the LLM the only external dependency; everything else runs locally.
