# Current State

Deze beschrijving vat de huidige werkwijze samen zoals vastgelegd in de werkinstructies van de afdeling Contractservice (versie 03/2026): P-100 (Contractbeëindiging), P-200 (Overlijden gemeld), P-210 (Overlijden, complexe constellatie) en P-300 (Beëindiging werkgeversverzekering).

## Overzicht van de vier processen

| Code | Naam | Toepassingsgebied | Volume |
|---|---|---|---|
| P-100 | Contractbeëindiging | Alle contractbeëindigende verzoeken (opzegging, bijzondere opzegging, herroeping, bezwaar) voor volledige zorgverzekering, aanvullende verzekering, collectieve werkgeversverzekering en verplichte langdurige zorg, exclusief overlijden en specifieke werkgeversbeëindiging | ca. 130 gedocumenteerde gevallen |
| P-200 | Overlijden gemeld | Standaardafhandeling van een gemeld overlijden van de verzekeringnemer | ca. 30.000 dossiers/jaar; ca. 285 gedocumenteerde verzoeken |
| P-210 | Overlijden (complexe constellatie) | Overlijden met contractovername, contractsplitsing of meerpersoonsconstellaties | ca. 54 gedocumenteerde overname-/splitsingsverzoeken |
| P-300 | Beëindiging werkgeversverzekering | Collectieve zorgverzekering via de werkgever (mantelcontract of individuele polis) | niet gekwantificeerd |

Afbakening tussen de processen (zoals toegepast door de afdeling):
- Overlijden van de verzekeringnemer: altijd P-200 (of P-210 bij complexe constellatie), nooit P-100.
- Beëindiging van een werkgeversverzekering: P-300, niet P-100.
- Opzegging van een reisziektekostenverzekering: wordt doorgestuurd naar het team Reisverzekeringen (geen eigen procescode in deze set).
- In de praktijk start elk overlijden met P-200; wanneer de constellatie vervolgacties vereist (overname/splitsing), wordt P-210 parallel of als vervolgproces aangemaakt.

---

## P-100 Contractbeëindiging

### Triggers / typische aanleidingen
- Gewone opzegging tegen contractafloop (opzegtermijn meestal 3 maanden).
- Bijzondere opzegging wegens premieverhoging (termijn 4 weken na ontvangst van de premieaanpassing).
- Bijzondere opzegging wegens wettelijke verzekeringsplicht (overgang naar publiek stelsel: werknemersstatus, studenten, gepensioneerden).
- Opzegging van afzonderlijke aanvullende tarieven binnen een meertarievencontract.
- Herroeping binnen de wettelijke termijn van 14 dagen.
- Bijzonder opzegrecht bij beëindiging beroep/verkoop praktijk (dagvergoedingsverzekering).

### Inkomende kanalen
Gemengd: ca. 40% telefoon, 25% e-mail, rest verdeeld over post, fax en elektronisch tussenpersoon-kanaal. Schriftelijk overheersen formele opzeggingsbrieven; telefonisch vooral vragen over opzegmogelijkheden.

### Actoren
- Verzekeringnemer: kan rechtstreeks opzeggen, handtekening verplicht.
- Gevolmachtigde: volmacht vereist, moet opzegging uitdrukkelijk omvatten.
- Verzekerde persoon (meerderjarig, niet verzekeringnemer): kan eigen tarief uit gezinscontract opzeggen.
- Ouders: kunnen contract van minderjarig kind opzeggen.
- Tussenpersoon: kan opzegging doorsturen namens klant, maar kan niet in eigen naam verklaren; handtekening verzekeringnemer blijft vereist.

### Processtappen (huidige werkwijze)
1. Inkomend document toewijzen aan contract in kernsysteem, procestype P-100 selecteren; bij telefonisch contact opzegintentie vastleggen in contactlog en klant wijzen op schriftelijke handtekeningplicht. Opzegtype vaststellen (gewoon / bijzonder / herroeping).
2. Contract openen (zoeken op polisnummer, geboortedatum+achternaam, of klantnummer); contractstatus controleren (ingangsdatum, minimale looptijd, volgende opzegdatum, lopende bijzondere opzegtermijnen).
3. Bevoegdheid van de opzegger controleren.
4. Werking van de opzegging en datum bepalen (afhankelijk van opzegtype).
5. Doorsturen bij specifieke branches (reisverzekering → team Reisverzekeringen; speciale tarieven → team Speciale Tarieven; dagvergoeding zelfstandigen → specialistische beoordeling).
6. Opzegging verwerken: contracteinddatum vastleggen, eventueel deelopzegging van afzonderlijk tarief; systeem genereert opzegbevestiging (type, einddatum, laatste premie-incasso/teruggave, bij bijzondere opzegging: wettelijke grondslag en bewijsverplichtingen).
7. Vervolgprocessen starten (F-410 voorgaande/vervolgverzekering, F-420 overdrachtswaarde, premieafrekening/teruggave) en dossier documenteren (opzegtype, datum van kracht, ontvangstdatum, reden, vervolgprocessen); dossier sluiten met status "afgehandeld".

### Bekende knelpunten / uitzonderingen (huidige staat)
- **Grootste faalpunt (ca. 75% faalkans)**: opzeggingen worden per e-mail ingediend zonder handgeschreven handtekening. Een opzegging is wettelijk vormgebonden (schriftelijk + handtekening); een enkele e-mailverklaring volstaat niet. Dit is in de data de meest voorkomende reden voor teruglegging bij de verzekeringnemer. Acceptabel: gescande/gefotografeerde ondertekende brief, brief, fax. Onvoldoende: e-mailverklaring zonder handtekening, mondelinge telefonische melding.
- Contract binnen minimale looptijd: gewone opzegging niet mogelijk; alternatieven zijn bijzonder opzegrecht, herroeping (indien binnen 14 dagen), of wachten tot einde minimale looptijd.
- Opzegging via tussenpersoon: regelmatig statusvragen ("Wij hebben een opzegging van de klant ingediend, is deze ontvangen?").
- Opzegging met terugwerkende kracht is in de particuliere zorgverzekering in beginsel niet mogelijk; komt veelvuldig voor als verzoek maar moet worden afgewezen (uitzondering: overgang naar publiek stelsel, ingangsdatum = datum overgang).
- Bewijs van vervolgverzekering ontbreekt vaak bij wisseling van aanbieder: opzegging is dan formeel onvolledig; dossier gaat in de wachtrij totdat bewijs wordt nagezonden.
- Opzegging van afzonderlijke tarieven in meertarievencontract: alleen het genoemde tarief wordt beëindigd, hoofdcontract blijft bestaan.

---

## P-200 Overlijden gemeld

### Triggers / typische aanleidingen
- Uitvaartonderneming meldt namens nabestaanden (meest voorkomend), overlijdensakte bijgevoegd.
- Directe melding door nabestaanden (echtgenoot, kinderen, familie).
- Melding door gevolmachtigden bij leven (voorzorgsvolmacht blijft van kracht).
- Melding via tussenpersoon.

### Inkomende kanalen
Overwegend schriftelijk: post ca. 40%, e-mail ca. 25%, tussenpersoon-kanaal ca. 17%, fax ca. 6%, telefoon ca. 5%.

### Processtappen (huidige werkwijze)
1. Inkomend document toewijzen aan contract, dossier aanmaken met procestype P-200; overlijdensakte als permanente bijlage toevoegen. Bij telefonische melding (zeldzaam, ca. 5%): verzoek om nazending van origineel/gewaarmerkte kopie van de akte; zonder akte kan formele beëindiging niet plaatsvinden.
2. Overlijdensakte controleren op volledigheid: naam/geboortedatum overledene vs. contractgegevens, overlijdensdatum, vorm (origineel/gewaarmerkt/gewone kopie).
3. Contract openen (polisnummer, geboortedatum+achternaam, klantnummer) en constellatie verhelderen: alleen verzekeringnemer verzekerd (volledige beëindiging) / verzekeringnemer + verdere verzekerden (voortzetting mogelijk, overnameverklaring vereist) / verzekerde (niet verzekeringnemer) overleden (alleen diens tarief beëindigen, contract blijft bestaan).
4. Beëindiging boeken: contract eindigt standaard met terugwerkende kracht per overlijdensdatum; premietegoed wordt automatisch berekend; vooruitbetaalde premie wordt teruggegeven. Uitbetaling premietegoed vereist een begunstigde (erfgenaam met verklaring van erfrecht, of gemeenschap van erfgenamen); bij grotere bedragen wordt dossier doorgestuurd naar team Tegoeden.
5. Communicatie met nabestaanden: brief met bevestiging beëindiging + datum, informatie premietegoed/uitbetaling, bij verdere verzekerden voortzettingsmogelijkheden + overnameverklaring, bij openstaande declaraties verwijzing naar verantwoordelijk onderdeel. Toon: respectvol en empathisch, geen gestandaardiseerde formuleringen.
6. Vervolgprocessen: uitbetaling tegoed, voortzetting bij verdere verzekerden (P-210 of apart vervolgproces), F-430 (verklaring nabestaandenpensioen), F-440 (belastingverklaring laatste volle jaar). Dossier documenteren (melder, overlijdensdatum, constellatie, premietegoedbedrag, vervolgprocessen) en sluiten met status "afgehandeld".

### Bekende knelpunten / uitzonderingen (huidige staat)
- **Veelvoorkomend faalpunt**: overlijdensakte wordt dubbel ingediend (nabestaanden, uitvaartonderneming en/of tussenpersoon melden onafhankelijk van elkaar). Vóór het opvragen van verdere documenten moet gecontroleerd worden of er al een P-200-dossier bestaat; zo ja, niet opnieuw opvragen maar verwijzen naar bestaand dossier.
- Overlijdensakte ontbreekt bij melding: dossier wordt aangemaakt, hervatting ingesteld over 14 dagen, nabestaanden krijgen beleefd verzoek tot nazending; beëindiging wordt pas geboekt zodra de akte aanwezig is.
- Uitvaartonderneming is geen formeel gevolmachtigde: voor verdere informatie (bijv. uitbetaling premietegoed) is rechtstreekse communicatie met nabestaanden of bewijs van erfopvolging vereist, al kan de beëindiging zelf op basis van de akte starten.
- Zonder overnameverklaring bij verdere verzekerden loopt de premiebetaling mogelijk door zonder dat de formele rol van verzekeringnemer is verhelderd, wat tot navolgende verheldering leidt.
- Openstaande (nog niet vergoede) zorgdeclaraties op moment van overlijden: aanspraak blijft bij gemeenschap van erfgenamen; dossier wordt doorgestuurd naar onderdeel Zorgdeclaraties.

---

## P-210 Overlijden (complexe constellatie)

### Triggers / typische aanleidingen
- Verzekeringnemer overlijdt, echtgenoot wil contract voortzetten als nieuwe verzekeringnemer (meest voorkomend geval, overnameverklaring).
- Verzekeringnemer overlijdt, kinderen krijgen aparte individuele contracten (contractsplitsing).
- Echtgenoot overlijdt als verzekerde (niet verzekeringnemer): alleen tarief wordt beëindigd, contract blijft bestaan.
- Voorbereidende vragen bij leven ("Wat gebeurt er met het contract als ik overlijd?").
- Overnameverklaring onvolledig of te laat ingediend (veelvoorkomend faalpunt).

### Inkomende kanalen
Overwegend schriftelijk (tussenpersoon-kanaal, e-mail, post); telefonisch contact betreft meestal statusvragen of voorbereidend advies.

### Processtappen (huidige werkwijze)
1. Inkomend document toewijzen, dossier aanmaken met procestype P-210; alle documenten (overnameverklaring, verzoek contractsplitsing, correspondentie) als bijlage toevoegen. Constellatie vaststellen: wie is overleden, welke verdere verzekerden staan op het contract (meerderjarig/minderjarig/zorgbehoevend), gewenste vervolgactie (overname/splitsing/beëindiging).
2. Contract openen; verhoogde bevoegdheidseisen: nieuwe verzekeringnemer moet verzekerde zijn op bestaand contract of erfgerechtigd; erfgenaam moet verklaring van erfrecht of gewaarmerkt testament overleggen; gevolmachtigde moet voorzorgsvolmacht hebben die over het overlijden heen reikt; uitvaartonderneming kan melden maar niet over overname beslissen.
3. Overnameverklaring verwerken (meest voorkomend geval): formulier controleren op volledigheid/handtekening/juiste gegevens, bevestiging niet-deelname aan groepsverzekering, nieuwe contractgegevens vastleggen, tariefstatus controleren.
4. Contractsplitsing verwerken: schriftelijk verzoek opvragen, nieuw polisnummer toekennen, tariefgegevens ongewijzigd overnemen, premieomzetting vastleggen, nieuwe polis verzenden. Bij minderjarige kinderen treedt de wettelijke vertegenwoordiger op als nieuwe verzekeringnemer.
5. Bijzonder geval verzekerde (niet verzekeringnemer) overleden: overlijdensakte controleren, tarief beëindigen per overlijdensdatum, premieafrekening aanpassen, condoleancebrief met bevestiging tariefbeëindiging aan verzekeringnemer.
6. Vervolgprocessen: P-200 (parallelle beëindiging overleden verzekeringnemer), F-430 (pensioenverklaring), F-440 (belastingverklaring), uitbetaling premietegoed. Dossier documenteren (constellatie, nieuwe verzekeringnemer, parallelle dossiers, tariefwijzigingen) en sluiten met status "afgehandeld".

### Bekende knelpunten / uitzonderingen (huidige staat)
- **Overname gebeurt niet automatisch**: moet actief door de nieuwe verzekeringnemer worden verklaard en ondertekend. Zonder actieve overnameverklaring loopt premiebetaling mogelijk door zonder verheldering van de formele rol. Bij ontbrekende verklaring: aanschrijven met formulier en verzoek om retournering, hervatting over 30 dagen. Bij uitdrukkelijke afwijzing: contract wordt volledig beëindigd (P-200-logica).
- Herhaaldelijk onvolledig ingediende overnameverklaringen: generieke standaardcorrespondentie wordt als ineffectief beschouwd; concrete, specifieke vragen over het ontbrekende gegeven worden toegepast.
- Vraag bij leven over wat er gebeurt bij overlijden: hiervoor is P-210 niet het juiste proces (contract blijft bestaan); wordt behandeld als adviesdossier (mondeling of adviesbrief) en gesloten. De overnameverklaring kan pas na het overlijden worden opgesteld.
- Meerdere verzekerden overlijden gelijktijdig (ongeval, natuurramp): alle overlijdensakten worden gebundeld, elke verzekerde afzonderlijk geboekt, communicatie vereist bijzondere gevoeligheid.

---

## P-300 Beëindiging werkgeversverzekering

### Bijzondere structuur van deze branche
- Verzekeringnemer is de werkgever, niet de individuele verzekerde.
- Verzekerden zijn medewerkers; formeel geen contractpartij maar begunstigde.
- Premie loopt doorgaans via de werkgever of loonadministratie (verstrekking in natura).
- Bij sommige tarieven bestaat een recht op voortzetting als individueel contract bij uitdiensttreding.

### Triggers / typische aanleidingen
- Werkgever zegt mantelcontract op (strategiewijziging, kosten, wisseling aanbieder).
- Medewerker treedt uit dienst (opzegging, pensionering, insolventie).
- Mantelcontract loopt regulier af (looptijd doorgaans 1-3 jaar).
- Verzekerde wil niet via collectieve regeling verzekerd zijn (opt-out).
- Correctie van dubbele polis (verzekerde per ongeluk dubbel opgenomen).

### Inkomende kanalen
Verschillen per aanleiding: opzeggingen van de werkgever komen schriftelijk (post, e-mail) van de HR-afdeling; verzoeken van individuele verzekerden komen vaker telefonisch of via een tussenpersoon.

### Processtappen (huidige werkwijze)
1. Inkomend document toewijzen aan collectief contract, procestype P-300 selecteren; aanleiding vaststellen (mantelcontract-opzegging door werkgever / uittreding of opt-out van één verzekerde / einde looptijd).
2. Contract openen (gezocht op mantelcontractnummer en/of personeelsnummer); formele structuur controleren: verzekeringnemer (werkgever), opgenomen verzekerden, tariefconstellatie. Bevoegdheidscontrole: werkgever (via HR/directie, handtekening bevoegd vertegenwoordiger), individuele verzekerde (eigen tarief, mits opt-out toegestaan), tussenpersoon (met volmacht werkgever).
3. Opzegging van het hele mantelcontract door de werkgever: opzegtermijn controleren (doorgaans 3 maanden), uniforme einddatum bepalen, alle verzekerden individueel informeren (voortzetting of beëindiging), eindafrekening met werkgever opstellen.
4. Beëindiging van één verzekerde (uittreding/opt-out): aanleiding verhelderen, einddatum bepalen (doorgaans einde maand), voortzettingsmogelijkheden communiceren, premieafrekening aanpassen.
5. Premie- en eindafrekening: bij einde mantelcontract eindafrekening met werkgever (alle verzekerden samen); bij beëindiging van één persoon premieaanpassing binnen lopend mantelcontract; bij terugwerkende beëindiging (bijv. dubbele polis) teruggave te veel betaalde premies.
6. Dossier documenteren (aanleiding, einddatum, betrokken personen, uitoefening voortzetting ja/nee/geen reactie, vervolgprocessen F-410/F-450) en sluiten met status "afgehandeld"; bij wachttijd op voortzettingsbeslissing wordt een passende hervatting ingesteld.

### Bekende knelpunten / uitzonderingen (huidige staat)
- **Recht op voortzetting als individueel contract**: bij veel collectieve tarieven hebben verzekerden recht om de dekking na einde van de regeling voort te zetten als individuele zorgverzekering, zonder nieuwe gezondheidsbeoordeling, met aanrekening van eerdere verzekerde tijdvakken. Dit recht moet actief worden gecommuniceerd, met een termijn van doorgaans 2 maanden. Bij uitoefening: apart proces F-450/F-460; bij niet-uitoefening: dekking eindigt op peildatum.
- Overstap naar nieuwe werkgever met eigen regeling: dekking eindigt doorgaans rechtstreeks; verklaring van voorgaande verzekering (F-410) wordt opgesteld als vervolgproces.
- Dubbele polis (fout bij inschrijving): correctie via P-300 als beëindiging van de overtollige polis, premies met terugwerkende kracht terugbetaald.
- Verzekerde wil uitdrukkelijk geen collectieve dekking: schriftelijke opt-out vereist, geaccepteerd door de werkgever; er ontstaat geen vervolgcontract.
- Afgrenzingsgeval: tijdelijke vrijstelling door werkgever (bijv. 1 jaar) is geen P-300-geval, maar vereist controle van een uitstelregeling.

---

## Gemeenschappelijke elementen over de vier processen
- Alle processen gebruiken hetzelfde kernsysteem voor dossieraanmaak, contractopzoeking (polisnummer / geboortedatum+achternaam / klantnummer) en statusafhandeling ("afgehandeld").
- Terugkerende vervolgprocessen: F-410 (voorgaande/vervolgverzekering), F-420 (overdrachtswaarde), F-430 (nabestaandenpensioen), F-440 (belastingverklaring), F-450/F-460 (nieuw individueel contract), F-470 (werkgeversbijdrage-verklaring).
- Bevoegdheids- en handtekeningvereisten vormen een terugkerend thema: schriftelijke handtekening van de contractpartij (of diens wettelijke vertegenwoordiger/erfgenaam) is in alle vier processen de formele basis voor een rechtsgeldige beëindiging of wijziging; tussenpersonen en uitvaartondernemingen kunnen melden/doorsturen maar niet namens de klant in eigen naam verklaren.
- Hervattingstermijnen (14 dagen bij ontbrekende overlijdensakte in P-200, 30 dagen bij ontbrekende overnameverklaring in P-210, impliciete wachttijd op voortzettingsbeslissing in P-300) worden gebruikt om dossiers open te houden tot ontbrekende documenten binnenkomen.
