# Process build bundle

This zip is the handover from the agentic-process-design tool. It contains:

- `specification.md`, `current-state.md`, `desired-behavior.md`, `constraints.md`
  — the process specification.
- `process-flow.json` — the authored process flow.
- `build-plan.md` — the prototype plan (file tree, agents, runtime).
- `handover-prompt.md` — a self-contained prompt for a coding agent.
- `build/` — the generated prototype source code (if you ran in-app codegen).
  Only files git is tracking are included, so anything in the prototype's
  own `.gitignore` (databases, `.venv`, `node_modules`, `.env`, etc.) is
  excluded automatically.

It does **not** contain any credentials. You supply your own.

## How to use

If `build/` is present, the prototype source is already there — `cd build`
and follow its README.

Otherwise, hand the bundle to a coding agent:

1. Unzip into an empty directory.
2. Open the directory in your coding agent of choice (Claude Code, Codex, Cursor).
3. Paste the contents of `handover-prompt.md` as your first message. The
   prompt references the other files in this directory by relative path,
   so the agent can read them directly.
4. Let the agent scaffold the prototype as described in `build-plan.md`.

## Credentials — bring your own

The generated prototype will need an Anthropic (or other LLM) API key to run.
The bundle ships only `.env.example` placeholders; before running the
prototype:

1. Copy `.env.example` to `.env` (or set the variables in your shell).
2. Set `ANTHROPIC_API_KEY` to your own key from https://console.anthropic.com/.
3. If you front Anthropic through a private gateway, also set `ANTHROPIC_BASE_URL`.
4. Make sure `.env` is git-ignored — it is by default in the generated `.gitignore`.

Nothing in this bundle came from the agentic-process-design backend's secrets.

---
_Workspace revision: `2ebc2642eb2cb582d660a70d6a87d6196722d533`_
