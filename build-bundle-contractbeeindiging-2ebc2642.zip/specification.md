## Overview

Dit document beschrijft de contractbeëindigingsprocessen van de afdeling Contractservice: P-100
(Contractbeëindiging), P-200 (Overlijden gemeld), P-210 (Overlijden, complexe constellatie) en P-300
(Beëindiging werkgeversverzekering), zoals vastgelegd in de werkinstructies versie 03/2026. De vier
processen vormen samen de volledige afhandeling van beëindigingsverzoeken binnen de particuliere en
collectieve zorgverzekering: van gewone opzegging tot overlijden en uittreding uit een collectief
werkgeverscontract.

De processen worden hier opnieuw vastgelegd omdat de huidige uitvoering, ondanks een duidelijk
voorgeschreven werkwijze, een aantal terugkerende knelpunten vertoont: een zeer hoog aandeel afgewezen
opzeggingen door ontbrekende handtekeningen (P-100), dubbele opvraging van overlijdensaktes (P-200),
ineffectieve generieke correspondentie bij onvolledige overnameverklaringen (P-210), en impliciete
afhankelijkheid van handmatige dossiercontroles voor afbakening tussen processen. Doel van deze
specificatie is de kloof tussen de voorgeschreven werkwijze (desired-behavior.md) en de praktijk zoals
vastgelegd in de huidige-staatbeschrijving (current-state.md) expliciet te maken, binnen de harde
randvoorwaarden uit constraints.md, zodat gerichte procesverbeteringen kunnen worden doorgevoerd.

---

## Current State

### Procesoverzicht
Vier processen, elk met een eigen toepassingsgebied en volume:

| Code | Naam | Toepassingsgebied | Volume |
|---|---|---|---|
| P-100 | Contractbeëindiging | Opzegging/bijzondere opzegging/herroeping/bezwaar, exclusief overlijden en werkgeversbeëindiging | ca. 130 gedocumenteerde gevallen |
| P-200 | Overlijden gemeld | Standaardafhandeling overlijden verzekeringnemer | ca. 30.000 dossiers/jaar |
| P-210 | Overlijden (complex) | Contractovername, -splitsing, meerpersoonsconstellaties | ca. 54 gedocumenteerde gevallen |
| P-300 | Beëindiging werkgeversverzekering | Collectieve zorgverzekering via werkgever | niet gekwantificeerd |

Afbakening in de praktijk: overlijden loopt altijd via P-200/P-210, nooit via P-100; werkgeversbeëindiging
loopt via P-300, nooit via P-100; reisziektekostenverzekering wordt doorgestuurd naar team
Reisverzekeringen. Elk overlijden start met P-200; P-210 wordt alleen parallel of als vervolgproces
aangemaakt wanneer de constellatie overname/splitsing vereist.

### Huidige werkwijze per proces
- **P-100**: document toewijzen → opzegtype vaststellen → contract en bevoegdheid controleren →
  werking/datum bepalen → eventueel doorsturen naar specialistische teams → verwerken en bevestiging
  versturen → vervolgprocessen (F-410, F-420) starten → dossier sluiten.
- **P-200**: document toewijzen, akte als bijlage → akte controleren op volledigheid → bestaand dossier
  checken → constellatie vaststellen → beëindiging met terugwerkende kracht boeken → premietegoed
  regelen → nabestaanden informeren → vervolgprocessen (P-210, F-430, F-440) → dossier sluiten.
- **P-210**: dossier + documenten vastleggen → constellatie vaststellen → verhoogde bevoegdheidscontrole
  → overnameverklaring of contractsplitsing verwerken → bijzonder geval verzekerde overleden →
  vervolgprocessen → dossier sluiten.
- **P-300**: document toewijzen aan collectief contract → aanleiding vaststellen → bevoegdheid controleren
  → mantelcontract- of individuele beëindiging verwerken → voortzettingsrecht communiceren → premie-
  /eindafrekening → dossier sluiten.

### Bekende knelpunten (huidige staat)
- **P-100**: ca. 75% faalkans doordat opzeggingen per e-mail zonder handtekening worden ingediend;
  dossiers moeten dan worden teruggelegd bij de klant. Daarnaast: veel statusvragen van tussenpersonen,
  vaak ontbrekend bewijs van vervolgverzekering, en verzoeken om terugwerkende opzegging die moeten
  worden afgewezen.
- **P-200**: overlijdensakte wordt vaak dubbel ingediend door meerdere melders onafhankelijk van elkaar;
  akte ontbreekt soms bij eerste melding; uitvaartondernemingen zijn geen formele gevolmachtigden voor
  vervolghandelingen.
- **P-210**: overname gebeurt nooit automatisch en wordt regelmatig onvolledig of te laat ingediend;
  generieke standaardcorrespondentie bij onvolledige verklaringen wordt in de praktijk als ineffectief
  beoordeeld; vragen "bij leven" worden soms per ongeluk als P-210-dossier behandeld.
- **P-300**: voortzettingsrecht als individueel contract moet actief gecommuniceerd worden, wat niet
  altijd gebeurt; afgrenzing tussen mantelcontract-opzegging en individuele uittreding/opt-out vraagt
  zorgvuldige vaststelling van de aanleiding.

### Gemeenschappelijke elementen
Alle processen gebruiken hetzelfde kernsysteem voor dossieraanmaak en contractopzoeking (polisnummer /
geboortedatum+achternaam / klantnummer, of mantelcontractnummer/personeelsnummer bij P-300).
Terugkerende vervolgprocessen zijn F-410, F-420, F-430, F-440, F-450/F-460 en F-470. Schriftelijke
handtekening van de bevoegde partij is in alle vier processen de formele basis voor een rechtsgeldige
beëindiging of wijziging. Hervattingstermijnen (14 dagen P-200, 30 dagen P-210, impliciete wachttijd
P-300) houden dossiers open tot ontbrekende documenten binnenkomen.

---

## Desired State

### Overkoepelend doel
- Elk verzoek wordt eenduidig aan het juiste procestype toegewezen (P-100/P-200/P-210/P-300), zodat de
  juiste bevoegdheids-, bewijs- en afrekenlogica wordt toegepast.
- Elk dossier krijgt uiteindelijk de status "afgehandeld", met volledige documentatie van verzoektype/
  reden, (ingangs)datum, betrokken partijen en gestarte vervolgprocessen.
- Correcte doorverwijzing tussen de vier processen en naar vervolgprocessen (F-410/F-420/F-430/F-440/
  F-450/F-460/F-470) is een expliciet onderdeel van "succesvol afgehandeld".

### Gewenst verloop en succescriteria per proces
- **P-100**: opzegtype en bevoegdheid eerst vaststellen; opzeggingen zonder geldige schriftelijke
  handtekening worden teruggelegd bij de verzekeringnemer, nooit verwerkt op basis van een enkele
  e-mailverklaring of telefonische melding; terugwerkende opzegging wordt afgewezen behalve bij
  overgang naar het publieke stelsel of herroeping; de systeem-gegenereerde opzegbevestiging wordt vóór
  verzending op datum-logica gecontroleerd; deelopzegging van één tarief laat het hoofdcontract
  ongemoeid.
- **P-200**: vóór het opvragen van documenten wordt altijd gecontroleerd of er al een P-200-dossier
  bestaat, om dubbele opvraging te voorkomen; zonder overlijdensakte wordt niet geboekt; communicatie
  met nabestaanden is respectvol, empathisch en vrij van generieke formuleringen, met navraag bij twijfel
  over de juiste geadresseerde; tijdige doorverwijzing naar P-210 zodra voortzetting aan de orde is.
- **P-210**: bevoegdheid wordt met verhoogde eisen getoetst (erfrecht/testament, volmacht die het
  overlijden overleeft, wettelijke vertegenwoordiger bij minderjarigen); bij onvolledige
  overnameverklaringen wordt concreet benoemd welk gegeven ontbreekt — generieke correspondentie is
  niet toegestaan, ook niet bij herhaalde onvolledige indiening; vragen "bij leven" worden als
  adviesdossier behandeld, niet als P-210; contractsplitsing en -overname worden zonder
  premieherwaardering van bestaande tarieven verwerkt.
- **P-300**: aanleiding (mantelcontract-opzegging / individuele uittreding / opt-out / einde looptijd)
  wordt eerst vastgesteld, omdat dit de vervolgstappen bepaalt; het voortzettingsrecht als individueel
  contract wordt actief gecommuniceerd met een duidelijke termijn (doorgaans 2 maanden), niet alleen
  passief beschikbaar gesteld; afbakening tussen hele-mantelcontract-beëindiging en individuele
  uittreding wordt expliciet bewaakt.

### Relevante randvoorwaarden (samengevat uit constraints.md)
- Wettelijke vormvereisten: schriftelijke handtekening (P-100), 14-dagen herroepingstermijn, overlijdensakte
  verplicht vóór formele beëindiging (P-200), schriftelijke ondertekende overnameverklaring (P-210).
- Bevoegdheidsregels: wie mag namens wie verklaren (verzekeringnemer, gevolmachtigde, erfgenaam,
  wettelijke vertegenwoordiger, werkgeversvertegenwoordiger); tussenpersonen en uitvaartondernemingen
  kunnen doorsturen/melden maar niet in eigen naam verklaren of beslissen.
- Verplichte proces-routering: overlijden nooit via P-100, werkgeversbeëindiging nooit via P-100,
  reisverzekering/speciale tarieven/zelfstandigen-dagvergoeding altijd doorsturen naar het juiste team.
- Dossier- en documentatieplicht: juiste toewijzing aan contract/procestype vóór verwerking; vaste
  kernvelden per dossier; geen herhaalde opvraging van reeds aanwezige documenten.
- Vaste hervattingstermijnen: 14 dagen (ontbrekende overlijdensakte), 30 dagen (ontbrekende
  overnameverklaring), 2 maanden (voortzettingsrecht P-300), 4 weken (bijzondere opzegging
  premieverhoging).

---

## Gaps & Required Changes

1. **Hoog faalpercentage bij opzegging zonder handtekening (P-100).** Current-state meldt dat ca. 75%
   van de opzeggingen faalt omdat ze per e-mail zonder handtekening binnenkomen; desired-behavior
   schrijft terecht voor dat zulke verzoeken worden teruggelegd, maar biedt geen mechanisme om het
   probleem bij de bron te verminderen. **Vereiste wijziging:** proactieve klantcommunicatie bij het
   eerste contactmoment (telefoon/e-mail) over de handtekeningvereiste, en/of een laagdrempelig
   alternatief (bijv. digitale ondertekening) vóórdat het dossier als onvolledig wordt teruggelegd.

2. **Geen systematische dubbeldetectie bij overlijdensmelding (P-200).** Desired-behavior vereist
   expliciet dat vóór het opvragen van documenten wordt gecontroleerd of er al een P-200-dossier bestaat;
   current-state beschrijft dit als een terugkerend faalpunt dat afhankelijk is van handmatige controle
   door de medewerker. **Vereiste wijziging:** een betrouwbare, systeemondersteunde dubbelcheck
   (koppeling op verzekeringnemer/contract) vóórdat een nieuw verzoek om de overlijdensakte wordt
   verstuurd.

3. **Generieke correspondentie bij onvolledige overnameverklaring (P-210).** Desired-behavior schrijft
   voor dat bij onvolledige overnameverklaringen concreet het ontbrekende gegeven wordt benoemd;
   current-state constateert dat de bestaande generieke standaardcorrespondentie als ineffectief wordt
   ervaren, zeker bij herhaalde onvolledige indiening. **Vereiste wijziging:** veldspecifieke
   correspondentietemplates (of een gerichte checklist) die de medewerker in staat stellen per ontbrekend
   gegeven een concrete vraag te stellen, in plaats van de huidige generieke brief.

4. **Validatie van de opzegbevestiging vóór verzending (P-100).** Desired-behavior noemt een
   controlestap op datum-logica vóór de systeem-gegenereerde opzegbevestiging wordt verstuurd;
   current-state beschrijft alleen dat het systeem de bevestiging genereert, zonder een voorafgaande
   controlestap. **Vereiste wijziging:** een expliciete validatiestap (handmatig of systematisch) tussen
   het vastleggen van de einddatum en het daadwerkelijk verzenden van de bevestiging.

5. **Verificatie van de geadresseerde bij nabestaanden-communicatie (P-200).** Desired-behavior vraagt
   om bij twijfel over de juiste geadresseerde navraag te doen in plaats van aan te nemen wie de brief
   moet ontvangen; current-state beschrijft de communicatiestap wel, maar zonder een expliciete
   verificatiestap voor de geadresseerde. **Vereiste wijziging:** een controlemoment in de workflow
   waarin bij meerdere mogelijke nabestaanden/erfgenamen expliciet wordt vastgesteld wie als
   geadresseerde optreedt, vóór verzending van de brief.

6. **Zichtbaarheid van dossierstatus voor tussenpersonen (P-100).** Current-state signaleert
   veelvoorkomende statusvragen van tussenpersonen ("is de opzegging ontvangen?"); desired-behavior
   adresseert dit niet met een structurele oplossing. Dit is geen harde eis uit constraints.md, maar een
   terugkerend operationeel knelpunt dat bij procesherontwerp meegenomen kan worden (bijv. een
   statusbevestiging bij ontvangst). Omdat dit niet expliciet als vereiste in desired-behavior.md of
   constraints.md is vastgelegd, wordt dit niet als harde gap behandeld — zie eventueel vervolgvraag in
   de inbox over de gewenste prioriteit hiervan.
