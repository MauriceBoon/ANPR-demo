# Build Plan — Contractbeëindiging (P-100 / P-200 / P-210 / P-300)

> Status: eerste versie. De vier build-vragen in de inbox staan nog open
> (`e6635190…` stack, `a1bf3453…` scope, `6cb6779f…` data, `0c92b67f…` notities).
> Dit plan gebruikt beredeneerde defaults; zie **Open questions**. Werk het plan
> bij met `edit_section` zodra de antwoorden binnen zijn.

## Goal

Dit prototype demonstreert de end-to-end afhandeling van contractbeëindigende
verzoeken binnen Contractservice: een binnenkomend verzoek wordt eenduidig naar
het juiste procestype gerouteerd (P-100 gewone opzegging, P-200 standaard
overlijden, P-210 complexe overlijdensconstellatie, P-300 werkgeversverzekering),
waarna het verzoek de voorgeschreven bevoegdheids-, bewijs- en afrekenlogica
doorloopt tot de status "afgehandeld". Het prototype maakt de gewenste
procesverbeteringen zichtbaar: de schriftelijke-handtekeningcheck in P-100 die
onbevoegde/ongetekende verzoeken teruglegt, de dubbeldetectie in P-200 die
voorkomt dat de overlijdensakte opnieuw wordt opgevraagd, de veldspecifieke
correspondentie in P-210 bij onvolledige overnameverklaringen, en de actieve
communicatie van het voortzettingsrecht in P-300. Het is een human-in-the-loop
caseworker-demo: een LLM leest/classificeert en stelt concepten op, een mens
keurt de kritieke beslissingen goed.

## Stack

**Gekozen (default): Streamlit single-file (Python) met `uv`.**

Streamlit past het best bij dit proces omdat het kern-UX een caseworker-workflow
is: één verzoek intake, een routeringsbeslissing, stapsgewijze knooppunten met
goedkeurmomenten (handtekening geldig? akte compleet? geadresseerde geverifieerd?)
en gegenereerde concept-correspondentie die een mens vóór verzending controleert.
Streamlit levert formulieren, status-badges, document-previews en
approve/reject-knoppen met minimale frontend-code, zodat de nadruk op de
proceslogica en de LLM-agents ligt. Eén externe afhankelijkheid: de LLM-provider
(Anthropic of OpenAI). Alles draait lokaal.

## File tree

```
.
├── app.py                      # Streamlit entrypoint: intake-form, router-UI, per-proces stappen, goedkeuringen
├── pyproject.toml              # deps + project-metadata (uv)
├── .env.example                # ANTHROPIC_API_KEY=your-key-here  (gitignored echte .env)
├── .gitignore
├── README.md                   # lokale run-instructies (uv), scope, caveats
├── core/
│   ├── __init__.py
│   ├── llm.py                  # dunne client-wrapper; leest key uit env; model-constant
│   ├── state.py                # Dossier/Case-datamodel, status-enums, in-memory + json-persist
│   ├── router.py               # route_process_type: kiest P-100/P-200/P-210/P-300/ander team
│   └── followups.py            # registratie vervolgprocessen F-410…F-470 (mock-stubs)
├── agents/
│   ├── __init__.py
│   ├── intake_classifier.py    # klassificeert kanaal/type verzoek -> procestype-suggestie
│   ├── p100.py                 # opzegtype, bevoegdheid, handtekening, datum, bevestiging-validatie
│   ├── p200.py                 # dubbelcheck, akte-volledigheid, constellatie, nabestaandenbrief
│   ├── p210.py                 # verhoogde bevoegdheid, overname/splitsing, veldspecifieke opvraag
│   └── p300.py                 # aanleiding, bevoegdheid, voortzettingsrecht-communicatie
├── data/
│   ├── seed.py                 # genereert synthetische voorbeeldcases per proces
│   ├── fixtures/               # plek voor eigen cases (leeg; .gitkeep)
│   └── cases.sample.json       # door seed.py geschreven voorbeeldcases
└── prompts/
    ├── intake.md
    ├── p100_signature.md
    ├── p200_relatives_letter.md
    ├── p210_missing_fields.md
    └── p300_continuation.md
```

## Agents

Default-model voor alle agents: `claude-opus-4-8` (configureerbaar via env/constante
in `core/llm.py`). Scope-default: **alle vier processen end-to-end implementeren**;
deterministische knooppunten (boeken, afrekenen, versturen) worden als lokale
stub-functies geïmplementeerd (geen echt kernsysteem), de human-knooppunten als
Streamlit-goedkeuringsstappen.

### Router — `route_process_type`
- Rol: wijst binnenkomend verzoek toe aan P-100/P-200/P-210/P-300 of "ander team".
- **Geïmplementeerd** (LLM-ondersteund + harde regels).
- Model: `claude-opus-4-8`.
- Inputs: ruwe verzoektekst, kanaal, bijlagen-metadata. Outputs: `process_type`
  + motivering.
- Harde routeringsregels dwingen de constraints af: overlijden nooit P-100;
  werkgeversbeëindiging nooit P-100; reis/speciale tarieven → ander team;
  "vraag bij leven" → adviesdossier, niet P-210.
- Promptschets: "Je classificeert een beëindigingsverzoek voor een
  zorgverzekeraar. Bepaal het procestype op basis van wie overlijdt/opzegt en het
  contracttype. Pas de verplichte scheidingsregels toe. Geef type + korte reden;
  bij twijfel markeer je voor menselijke beoordeling."

### P-100 — opzegging/herroeping
- Rol: opzegtype vaststellen, contract openen, bevoegdheid + schriftelijke
  handtekening controleren, ingangsdatum bepalen, bevestiging genereren en
  valideren.
- **Geïmplementeerd.** Model: `claude-opus-4-8`.
- Kritieke gate (gewenste verbetering): **handtekeningcheck** — ongetekende e-mail
  of telefonische melding ⇒ `p100_signature_missing` ⇒ dossier teruggelegd bij
  klant. Terugwerkende opzegging afwijzen behalve publiek stelsel/herroeping.
  Opzegbevestiging vóór "verzenden" valideren op datum-logica (human-gate).
- Promptschets: "Beoordeel of een geldige, schriftelijke, ondertekende opzegging
  aanwezig is (brief/scan/fax = geldig; ongetekende e-mail/telefoon = ongeldig).
  Bepaal opzegtype en ingangsdatum volgens de regels; wijs terugwerkende opzegging
  af tenzij overgang publiek stelsel of herroeping binnen 14 dagen."

### P-200 — standaard overlijden
- Rol: dossier aanmaken, dubbelcheck, akte-volledigheid, constellatie,
  beëindiging boeken, premietegoed, geadresseerde verifiëren, nabestaandenbrief.
- **Geïmplementeerd.** Model: `claude-opus-4-8`.
- Kritieke gates (gewenste verbeteringen): **dubbeldetectie** vóór opvragen
  (match op verzekeringnemer/contract ⇒ verwijzen naar bestaand dossier, geen
  nieuwe aktevraag); geen boeking zonder akte (hervatting 14 dagen);
  **geadresseerde-verificatie** vóór verzending; empathische, niet-generieke brief.
- Promptschets: "Stel een respectvolle, empathische brief aan nabestaanden op met
  bevestiging beëindiging + datum, premietegoed-info en voortzettingsmogelijkheden.
  Vermijd generieke standaardformuleringen. Benoem bij twijfel over de
  geadresseerde dat navraag nodig is."

### P-210 — complexe overlijdensconstellatie
- Rol: verhoogde bevoegdheidscontrole, overnameverklaring verwerken,
  contractsplitsing, overlijden verzekerde, "vraag bij leven" → adviesdossier.
- **Geïmplementeerd.** Model: `claude-opus-4-8`.
- Kritieke gate (gewenste verbetering): **veldspecifieke opvraag** — bij
  onvolledige overnameverklaring exact benoemen welk gegeven ontbreekt (geen
  generieke "gelieve volledig"-brief), ook bij herhaalde onvolledige indiening;
  hervatting 30 dagen.
- Promptschets: "Controleer de overnameverklaring veld voor veld (ondertekening,
  juiste gegevens, niet-deelname groepsverzekering). Noem bij onvolledigheid
  concreet welke velden ontbreken en stel per ontbrekend veld een gerichte vraag
  op. Gebruik nooit generieke correspondentie."

### P-300 — werkgeversverzekering
- Rol: aanleiding vaststellen, bevoegdheid, hele mantelcontract vs. één
  verzekerde, voortzettingsrecht actief communiceren, premie-/eindafrekening.
- **Geïmplementeerd.** Model: `claude-opus-4-8`.
- Kritieke gate (gewenste verbetering): **actieve communicatie voortzettingsrecht**
  met termijn (2 maanden), niet passief; strikte afbakening heel mantelcontract
  vs. individuele uittreding.
- Promptschets: "Stel een individuele informatiebrief op over het recht op
  voortzetting als individueel contract, zonder nieuwe gezondheidsbeoordeling,
  met een uitoefentermijn van doorgaans 2 maanden. Maak expliciet onderscheid
  tussen opzegging van het hele mantelcontract en uittreding van één verzekerde."

### Deterministische knooppunten (lokale stubs, geen LLM)
`p100_process_termination`, `p100_send_confirmation`, `p100_close_dossier`,
`p200_book_termination`, `p200_close_dossier`, `p210_close_dossier`,
`p300_settle_premium`, `p300_close_dossier`. Deze berekenen/boeken lokaal
(datum/premietegoed) en zetten dossierstatus; vervolgprocessen F-410…F-470 worden
via `core/followups.py` alleen geregistreerd (stub).

## Data shapes

Afgeleid van `process-flow.json` (`outputs`/`preconditions` per node).

**Case / Dossier (in-memory, persist als JSON in `data/cases.*.json`):**
```
Case {
  id: str
  channel: "telefoon"|"e-mail"|"post"|"fax"|"tussenpersoon"
  raw_request: str
  attachments: [ {kind, filename, meta} ]          # bv. overlijdensakte, overnameverklaring
  process_type: "P-100"|"P-200"|"P-210"|"P-300"|"ANDER_TEAM" | null
  contract: { policy_no, dob, surname, customer_no, mantel_no?, personnel_no? }
  outputs: { <output_key>: value }                 # bv. p100_signature_valid=true
  status: "nieuw"|"in_behandeling"|"teruggelegd"|"wacht_op_document"|"afgehandeld"
  resume_at: date | null                           # hervatting: 14d / 30d / 2mnd
  followups: [ "F-410", "F-420", ... ]
  audit: [ {ts, actor:"mens"|"ai", step, decision, rationale, model_version?} ]
}
```

**Node-output-vlaggen** (gebruik exact de keys uit `process-flow.json`), o.a.:
`process_type_assigned`, `p100_signature_valid`/`p100_signature_missing`,
`p200_duplicate_found`/`p200_duplicate_checked`,
`p200_certificate_present`/`p200_certificate_missing`,
`p210_takeover_complete`/`p210_takeover_incomplete`/`p210_takeover_rejected`,
`p210_is_living_question`, `p300_is_full_contract`/`p300_is_single_person`,
`p300_continuation_exercised`/`p300_continuation_not_exercised`.

**Agent-I/O**: elke agent krijgt de `Case` (of relevante subset) en geeft een
gestructureerd resultaat terug (bv. `{signature_valid: bool, reason: str}` of een
concept-brieftekst) plus een audit-regel.

## Runtime

Python-tooling-default: **`uv`** (geïsoleerde env, geen vervuiling van globale
Python). Credentials komen uit een lokale, gitignorede `.env`; commit alleen
`.env.example` met placeholders. Nooit een key hardcoden.

```
# 1. kopieer env-template en vul je eigen key in
cp .env.example .env
#    .env bevat: ANTHROPIC_API_KEY=your-key-here

# 2. omgeving + dependencies
uv venv
uv sync                       # of: uv pip install -e .

# 3. voorbeelddata genereren
uv run python data/seed.py

# 4. app starten
uv run streamlit run app.py
```

De app gebruikt de publieke provider-endpoint (Anthropic / OpenAI). Geen interne
gateway-URL's. Als de gebruiker een andere provider wil, past die alleen env-vars
aan.

## Open questions

- `e6635190288e4ee89a3e038411c34cc1` — **Stack** nog niet bevestigd; plan gaat uit
  van Streamlit single-file (Python). Pas Stack + File tree aan bij ander antwoord.
- `a1bf34535b42450295437ccb12a8c251` — **Scope** nog niet bevestigd; plan gaat uit
  van alle vier processen end-to-end. Bij "alleen kritiek pad" of "alleen router":
  markeer de overige agents als mocked.
- `6cb6779f5b9e4cdb973353015a944b2e` — **Data** nog niet bevestigd; plan gaat uit
  van synthetische seed + lege `fixtures/`.
- `0c92b67feea04234b92ed6a6e29d6566` — **Notities** nog niet bevestigd; plan legt
  de nadruk op de gewenste verbeteringen en lokale demo-vriendelijkheid.

> Let op reikwijdte: de LLM-agents in dit prototype dekken de vier zorg-processen
> (P-100…P-300). Het POL-KS-017-beleid (schadeverzekeringen na overlijden, DORA/
> AI-governance) staat in de bronnen maar valt **buiten** de process-flow.json en
> dus buiten dit prototype; neem het niet mee tenzij een vervolgvraag dit vraagt.
